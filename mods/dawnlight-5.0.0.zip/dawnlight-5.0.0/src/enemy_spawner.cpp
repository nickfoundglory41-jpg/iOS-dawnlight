#include "enemy_spawner.hpp"
#include "survivors.hpp"
#include "process_actor.hpp"

#include "save_state.hpp"
#include "bow_fire_resource.hpp"
#include "service_imports.hpp"

#include "SSystem/SComponent/c_math.h"
#include "d/actor/d_a_alink.h"
#include "d/actor/d_a_e_tk.h"
#include "d/actor/d_a_e_tk2.h"
#include "d/actor/d_a_e_zs.h"
#include "d/d_com_inf_game.h"
#include "f_op/f_op_actor_mng.h"
#include "f_pc/f_pc_method.h"
#include "f_pc/f_pc_layer.h"
#include "f_pc/f_pc_name.h"
#include "mods/hook.hpp"

#include <array>
#include <cstring>
#include <unordered_set>
#include <utility>
#include <vector>

namespace dawnlight {
namespace {

constexpr std::array<ProfileName, kEnemySpawnerProfileLabels.size()> kEnemySpawnerProfiles{
    fpcNm_B_TN_e,  // Darknut
    fpcNm_E_OC_e,  // Bokoblin
    fpcNm_E_FZ_e,  // Mini Freezard
    fpcNm_E_BA_e,  // Keese
    fpcNm_E_BA_e,  // Fire Keese
    fpcNm_E_BA_e,  // Ice Keese
    fpcNm_E_TT_e,  // Tektite
    fpcNm_E_GI_e,  // Gibdo
    fpcNm_NPC_GRA_e,  // Goron
    fpcNm_E_ZS_e,  // Staltroop
    fpcNm_B_GG_e,  // Aeralfos
    fpcNm_E_KK_e,  // Chilfos
    fpcNm_E_FB_e,  // Freezard
    fpcNm_E_BS_e,  // Stalchild
    fpcNm_E_BU_e,  // Bubble
    fpcNm_E_BU_e,  // Fire Bubble
    fpcNm_E_BU_e,  // Ice Bubble
    fpcNm_E_MS_e,  // Rat
    fpcNm_E_WW_e,  // White Wolfos
    fpcNm_E_FS_e,  // Puppet
    fpcNm_E_CR_e,  // Bomskit
    fpcNm_E_SH_e,  // Stalhound
    fpcNm_E_TK_e,  // Water Toadpoli
    fpcNm_E_TK2_e,  // Fire Toadpoli
    fpcNm_E_RD_e,  // Bulblin
    fpcNm_E_DN_e,  // Lizalfos
    fpcNm_E_DD_e,  // Dodongo
    fpcNm_E_MF_e,  // Dynalfos
    fpcNm_E_ST_e,  // Skulltula
    fpcNm_E_HB_e,  // Baba Serpent
    fpcNm_E_GB_e,  // Big Baba
    fpcNm_E_DB_e,  // Deku Baba
    fpcNm_E_SF_e,  // Stalfos
    fpcNm_E_MM_e,  // Helmasaur
    fpcNm_E_MM_e,  // Helmasaurus (argument 1)
    fpcNm_E_KR_e,  // Kargarok
    fpcNm_E_GE_e,  // Guay
    fpcNm_E_AI_e,  // Armos
    fpcNm_E_SM2_e, // Red Chu
    fpcNm_E_SM2_e, // Blue Chu
    fpcNm_E_SM2_e, // Yellow Chu
    fpcNm_E_SM2_e, // Purple Chu
    fpcNm_E_SM2_e, // Black Chu
};

// Darknut treats type 0 as its room-opening demo. Type 1 is the ordinary waitable
// variant; 0xff means that no defeated-state switch is attached to the test actor.
constexpr std::array<u32, kEnemySpawnerProfiles.size()> kEnemySpawnerParameters{
    0x000001ff,  // Darknut
    0x00ff0000,  // Bokoblin: no defeated switch
    0,           // Mini Freezard
    0xffff0f01,  // Keese: flying, default detection radius, no path/switch
    0xffff1f01,  // Fire Keese: flying, default detection radius, no path/switch
    0xffff2f01,  // Ice Keese: flying, default detection radius, no path/switch
    0x000000ff,  // Tektite: red, no defeated switch
    0x00ff01ff,  // Gibdo: awake, no activation/defeated switches
    0,           // Goron
    0,           // Staltroop
    0xffff0002,  // Aeralfos: regular flying enemy, no arena demo/switches
    0x00ff0000,  // Chilfos: normal body, no defeated switch
    0x00ffff00,  // Freezard: no switches
    0x00ffff00,  // Stalchild: normal, default detection radius, no switch
    0xffff0f00,  // Bubble: no path/switch, default detection radius
    0xffff1f00,  // Fire Bubble: no path/switch, default detection radius
    0xffff2f00,  // Ice Bubble: no path/switch, default detection radius
    0xffff0000,  // Rat: no activation/defeated switches
    0x03000000,  // White Wolfos: individual, not the invisible pack controller
    0,           // Puppet
    0,           // Bomskit
    0x00ffff00,  // Stalhound: default detection/leash radii (night only)
    0x00ff0000,  // Water Toadpoli: no path
    0,           // Fire Toadpoli
    0xff000100,  // Bulblin: club, no defeated switch
    0xff000000,  // Lizalfos: no defeated switch
    0xffff0000,  // Dodongo: no path or defeated switch
    0xff000000,  // Dynalfos: no defeated switch
    0xff000002,  // Skulltula: ground variant, no defeated switch
    0xff000000,  // Baba Serpent: no defeated switch
    0x00ffff00,  // Big Baba: no defeated/intro switches
    0xff000000,  // Deku Baba: no defeated switch
    0x0000ff00,  // Stalfos: normal standing variant, default detection radius
    0x0000ff00,  // Helmasaur: no defeated switch
    0x0000ff00,  // Helmasaurus: no defeated switch
    0xffffff00,  // Kargarok: flying, no path
    0x00ffff01,  // Guay: flying, no group/switch
    0x00ff000a,  // Armos: no defeated switch, 1000-unit home radius
    0xffff0010,  // Red Chu: small ground variant, no switch
    0xffff0020,  // Blue Chu
    0xffff0030,  // Yellow Chu
    0xffff0040,  // Purple Chu
    0xffff0060,  // Black Chu
};

constexpr int kHelmasaurusIndex = 34;
static_assert(kEnemySpawnerProfiles[kHelmasaurusIndex] == fpcNm_E_MM_e);

DEFINE_HOOK(&fpcMtd_Method, SpawnerProcessHook);
DEFINE_HOOK(&fopAcM_createChild, SpawnerChildHook);
DEFINE_HOOK(static_cast<u32 (dPa_control_c::*)(u32,u8,u16,const cXyz*,const dKy_tevstr_c*,const csXyz*,
    const cXyz*,u8,dPa_levelEcallBack*,s8,const GXColor*,const GXColor*,const cXyz*,f32)>(&dPa_control_c::set),SpawnerFireHook);
DEFINE_HOOK(&daE_ZS_c::executeAppear, StaltroopAppearHook);
DEFINE_HOOK(&daE_ZS_c::executeWait, StaltroopWaitHook);

std::unordered_set<ActorId> s_testActors;
// fpcMtd_Method nests (base actor creation calls profile creation). Track the
// innermost process so a nested gate/NPC never inherits a test enemy's state.
std::vector<std::pair<void*, bool>> s_testProcessStack;
bool s_processHookInstalled = false;
bool s_childHookInstalled = false;
bool s_fireHookInstalled = false;
bool s_appearHookInstalled = false;
bool s_waitHookInstalled = false;

bool is_test_actor(fopAc_ac_c* actor) {
    return actor != nullptr && s_testActors.contains(fopAcM_GetID(actor));
}

void after_create_child(ModContext*, void* args, void* retval, void*) {
    if (args == nullptr || retval == nullptr) return;
    const auto parent = mods::arg<fpc_ProcID>(args, 1);
    const auto child = *static_cast<fpc_ProcID*>(retval);
    // Child creation is asynchronous. Register the returned ID now, before
    // fopAc_Create checks room admission (and before actor_type exists).
    // This includes descendants, but never unrelated native room actors.
    if (child != fpcM_ERROR_PROCESS_ID_e && s_testActors.contains(parent)) {
        s_testActors.insert(child);
    }
}

HookAction before_process(ModContext*, void* args, void*, void*) {
    auto* process = mods::arg<void*>(args, 1);
    // The room's enemy-appearance switch is read in base creation, before the
    // first fopAcM_IsActor check can succeed. Process IDs already exist here.
    s_testProcessStack.emplace_back(args, is_base_process(process) && s_testActors.contains(fpcM_GetID(process)));
    if (process == nullptr || !is_actor_process(process)) return HOOK_CONTINUE;
    auto* actor = static_cast<fopAc_ac_c*>(process);
    if (!is_test_actor(actor)) return HOOK_CONTINUE;
    const auto* methods = reinterpret_cast<const process_method_class*>(actor->sub_method);
    if (methods == nullptr) return HOOK_CONTINUE;
    const auto method = mods::arg<process_method_func>(args, 0);
    if (method == methods->delete_method) {
        s_testActors.erase(fopAcM_GetID(actor));
    } else if (method == methods->execute_method) {
        if (fopAcM_GetName(actor) == fpcNm_E_TK_e) {
            // Keep standalone test actors at the chosen spawn height in rooms
            // without a suitable water surface.
            static_cast<e_tk_class*>(actor)->mExecuteState = 2;
        } else if (fopAcM_GetName(actor) == fpcNm_E_TK2_e) {
            // Vanilla anchors to lava after this timer expires. Test actors use
            // the ground chosen at spawn, including in rooms without lava.
            static_cast<e_tk2_class*>(actor)->mActionTimer[3] = 2;
        } else if (fopAcM_GetName(actor) == fpcNm_E_ZS_e) {
            // Prevent the arena-owner check from retiring this standalone actor.
            static_cast<daE_ZS_c*>(actor)->field_0x671 = 2;
        }
    }
    return HOOK_CONTINUE;
}

void after_process(ModContext*, void* args, void*, void*) {
    // Another mod may skip the call before our pre callback is reached.
    if (!s_testProcessStack.empty() && s_testProcessStack.back().first == args) {
        s_testProcessStack.pop_back();
    }
}

HookAction before_staltroop_appear(ModContext*, void* args, void*, void*) {
    auto* actor = mods::arg<daE_ZS_c*>(args, 0);
    if (is_test_actor(actor) && actor->mMode == 0) actor->mMode = 1;
    return HOOK_CONTINUE;
}

HookAction before_staltroop_wait(ModContext*, void* args, void*, void*) {
    auto* actor = mods::arg<daE_ZS_c*>(args, 0);
    if (!is_test_actor(actor)) return HOOK_CONTINUE;
    if (actor->mMode == 0) {
        actor->setBck(7, 2, 3.0f, 1.0f);
        actor->mMode = 1;
    }
    // The original idle retires the actor when Stallord is absent. Damage,
    // collision, appearance and death still run through the original actor.
    cLib_addCalcAngleS2(&actor->current.angle.y, fopAcM_searchPlayerAngleY(actor), 8, 0x1000);
    actor->shape_angle.y = actor->current.angle.y;
    return HOOK_SKIP_ORIGINAL;
}

ModResult create_test_actor_in_player_layer(daAlink_c* player, ProfileName profile,
    const ActorSpawnParams& params, ActorId& id) {
    if (player == nullptr || dComIfGp_isEnableNextStage()) return MOD_UNAVAILABLE;
    auto* layer = player->layer_tag.layer;
    if (layer == nullptr || layer == fpcLy_RootLayer() || fpcLy_IsDeletingMesg(layer)) {
        return MOD_UNAVAILABLE;
    }

    // UI callbacks run outside actor execution, often on the root layer.
    // ActorService forwards that current layer to the async creation request;
    // room_num alone does not assign scene ownership. A root actor is drawn
    // both by the play scene's actor queue AND root traversal, and survives
    // play-scene deletion. Use Link's owner for drawing and scene teardown.
    struct RestoreLayer {
        layer_class* previous;
        ~RestoreLayer() { fpcLy_SetCurrentLayer(previous); }
    } restore{fpcLy_CurrentLayer()};
    fpcLy_SetCurrentLayer(layer);
    return svc_actor->create_actor(mod_ctx, profile, &params, &id);
}

HookAction before_dodongo_fire(ModContext*,void* args,void*,void*) {
    if(!enemy_spawner_process_active())return HOOK_CONTINUE;
    auto* actor=static_cast<fopAc_ac_c*>(mods::arg<void*>(s_testProcessStack.back().first,1));
    if(!actor)return HOOK_CONTINUE;
    auto& effect=mods::arg_ref<u16>(args,3);
    const auto profile=fopAcM_GetName(actor);
    u16 imported=0;
    if(profile==fpcNm_E_DD_e)imported=dodongo_fire_effect(effect);
    else if(profile==fpcNm_B_DS_e || profile==fpcNm_E_VT_e)
        imported=boss_attack_effect(effect,profile==fpcNm_B_DS_e);
    if(imported)effect=imported;
    return HOOK_CONTINUE;
}

ModResult install_test_hooks() {
    if(!s_fireHookInstalled) {
        const auto result=mods::hook::add_pre<SpawnerFireHook>(svc_hook,before_dodongo_fire);
        if(result!=MOD_OK)return result;
        s_fireHookInstalled=true;
    }
    if (!s_childHookInstalled) {
        const auto result = mods::hook::add_post<SpawnerChildHook>(svc_hook, after_create_child);
        if (result != MOD_OK) return result;
        s_childHookInstalled = true;
    }
    if (!s_processHookInstalled) {
        const auto result = mods::hook::add_pre<SpawnerProcessHook>(svc_hook, before_process);
        if (result != MOD_OK) return result;
        const auto postResult = mods::hook::add_post<SpawnerProcessHook>(svc_hook, after_process);
        if (postResult != MOD_OK) {
            mods::hook::uninstall<SpawnerProcessHook>(svc_hook);
            return postResult;
        }
        s_processHookInstalled = true;
    }
    if (!s_appearHookInstalled) {
        const auto result = mods::hook::add_pre<StaltroopAppearHook>(svc_hook, before_staltroop_appear);
        if (result != MOD_OK) return result;
        s_appearHookInstalled = true;
    }
    if (!s_waitHookInstalled) {
        const auto result = mods::hook::add_pre<StaltroopWaitHook>(svc_hook, before_staltroop_wait);
        if (result != MOD_OK) return result;
        s_waitHookInstalled = true;
    }
    return MOD_OK;
}

}  // namespace

ModResult create_standalone_actor(ProfileName profile, const ActorSpawnParams& params, ActorId& id) {
    if (!svc_actor || !svc_actor->create_actor) return MOD_UNAVAILABLE;
    const auto hooks = install_test_hooks();
    if (hooks != MOD_OK) return hooks;
    const auto result = create_test_actor_in_player_layer(daAlink_getAlinkActorClass(), profile, params, id);
    if (result == MOD_OK) s_testActors.insert(id);
    return result;
}

bool enemy_spawner_process_active() {
    return !s_testProcessStack.empty() && s_testProcessStack.back().second;
}

bool enemy_spawner_blocked_in_bossrush_hub() {
    constexpr char kBossRushHubStage[] = "D_MN09C";
    constexpr s8 kBossRushHubRoom = 0;
    constexpr u8 kBossRushHubState = 0;
    const char* stage = dComIfGp_getStartStageName();
    return save_state_boss_rush_active() &&
           save_state_boss_rush_state() == kBossRushHubState && stage != nullptr &&
           std::strcmp(stage, kBossRushHubStage) == 0 &&
           dComIfGp_getStartStageRoomNo() == kBossRushHubRoom;
}

ModResult spawn_enemy_for_testing(int profileIndex) {
    if (survivors_active()) return MOD_UNAVAILABLE;
    if (profileIndex < 0 ||
        static_cast<std::size_t>(profileIndex) >= kEnemySpawnerProfiles.size()) {
        return MOD_INVALID_ARGUMENT;
    }
    if (svc_actor == nullptr || svc_actor->create_actor == nullptr) return MOD_UNAVAILABLE;
    // Keep the existing mirror-hub restriction; the separate empty arena is allowed.
    if (enemy_spawner_blocked_in_bossrush_hub()) return MOD_UNAVAILABLE;

    auto* link = daAlink_getAlinkActorClass();
    if (link == nullptr) return MOD_UNAVAILABLE;

    const auto hookResult = install_test_hooks();
    if (hookResult != MOD_OK) return hookResult;

    constexpr float kSpawnDistance = 300.0f;
    const s16 facing = link->shape_angle.y;
    cXyz position{
        link->current.pos.x + cM_ssin(facing) * kSpawnDistance,
        link->current.pos.y,
        link->current.pos.z + cM_scos(facing) * kSpawnDistance,
    };
    cXyz probe = position;
    probe.y += 500.0f;
    dBgS_ObjGndChk ground;
    ground.SetPos(&probe);
    const float groundY = dComIfG_Bgsp().GroundCross(&ground);
    if (groundY == -1.0e9f) return MOD_UNAVAILABLE;
    position.y = groundY;
    const auto profile = kEnemySpawnerProfiles[static_cast<std::size_t>(profileIndex)];
    if (profile == fpcNm_E_BA_e || profile == fpcNm_E_BU_e || profile == fpcNm_B_GG_e ||
        profile == fpcNm_E_KR_e || profile == fpcNm_E_GE_e) {
        position.y += 200.0f;
    }
    // Stalfos and Kargarok encode their defeated switch in angle.z.
    const s16 angleZ = (profile == fpcNm_E_SF_e || profile == fpcNm_E_KR_e) ? 0xff : 0;
    const csXyz angle{0, static_cast<s16>(facing + 0x8000), angleZ};
    const ActorSpawnParams params{
        .parameters = kEnemySpawnerParameters[static_cast<std::size_t>(profileIndex)],
        .argument = static_cast<s8>(profileIndex == kHelmasaurusIndex ? 1 : -1),
        .room_num = fopAcM_GetRoomNo(link),
        .position = {position.x, position.y, position.z},
        .angle = {angle.x, angle.y, angle.z},
        .scale = {1.0f, 1.0f, 1.0f},
        .create_function = nullptr,
    };

    ActorId actorId = fpcM_ERROR_PROCESS_ID_e;
    const auto result = create_test_actor_in_player_layer(link, profile, params, actorId);
    if (result == MOD_OK) s_testActors.insert(actorId);
    return result;
}

}  // namespace dawnlight

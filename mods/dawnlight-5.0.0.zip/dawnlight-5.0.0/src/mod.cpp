#include "survivors.hpp"
#include "touch_buttons.hpp"
#include "bow_modes.hpp"
#include "bullet_time.hpp"
#include "boss_hard_mode.hpp"
#include "cave_randomizer.hpp"
#include "config.hpp"
#include "dual_wield.hpp"
#include "collection_dual_wield.hpp"
#include "fierce_deity.hpp"
#include "fierce_deity_hud.hpp"
#include "kh2_hud_compat.hpp"
#include "dawnlight/kh2_hud_drive.h"
#include "gale_counter.hpp"
#include "hud_fade.hpp"
#include "epona_spurs_hud.hpp"
#include "great_spin_projectile.hpp"
#include "model_overlays.hpp"
#include "player_hard_mode.hpp"
#include "save_compat.hpp"
#include "save_state.hpp"
#include "progression.hpp"
#include "service_imports.hpp"
#include "stamina.hpp"
#include "twilit_essentials/stamina.h"
#include "twilit_essentials/collection.h"
#include "update_service.hpp"

#include "mods/service.hpp"
#include "mods/svc/actor.h"
#include "mods/svc/config.h"
#include "mods/svc/flow.h"
#include "mods/svc/game_mode.h"
#include "mods/svc/gfx.h"
#include "mods/svc/hook.h"
#include "mods/svc/host.h"
#include "mods/svc/log.h"
#include "mods/svc/message.h"
#include "mods/svc/overlay.h"
#include "mods/svc/save.h"
#include "mods/svc/texture.h"
#include "mods/svc/ui.h"

DEFINE_MOD();
IMPORT_SERVICE(ActorService, svc_actor);
IMPORT_OPTIONAL_SERVICE(Kh2HudDriveService, svc_kh2hud_drive);
IMPORT_OPTIONAL_SERVICE_VERSION(TwilitEssentialsStaminaService, svc_te_stamina, 0);
IMPORT_OPTIONAL_SERVICE(TwilitEssentialsCollectionService, svc_te_collection);
IMPORT_SERVICE(ConfigService, svc_config);
IMPORT_OPTIONAL_SERVICE(FileService, svc_file);
IMPORT_SERVICE(FlowService, svc_flow);
IMPORT_SERVICE(GameModeService, svc_game_mode);
IMPORT_SERVICE(GfxService, svc_gfx);
IMPORT_SERVICE(HookService, svc_hook);
IMPORT_SERVICE(HostService, svc_host);
IMPORT_SERVICE(LogService, svc_log);
IMPORT_SERVICE(MessageService, svc_message);
IMPORT_SERVICE(OverlayService, svc_overlay);
IMPORT_SERVICE(SaveService, svc_save);
IMPORT_SERVICE(TextureService, svc_texture);
IMPORT_SERVICE(UiService, svc_ui);

namespace dawnlight {
ModResult install_aim_hooks(ModError* error);
ModResult install_enemy_scaling_hooks(ModError* error);
ModResult install_eye_movement_hooks(ModError* error);
ModResult install_item_integrity_hooks(ModError* error);
ModResult install_item_slot_hooks(ModError* error);
ModResult install_jump_hooks(ModError* error);
ModResult install_manual_shield_hooks(ModError* error);
ModResult register_new_save_modes(ModError* error);
ModResult register_ui(ModError* error);
void update_new_save_modes();
void shutdown_item_slot_hooks();
void shutdown_jump_hooks();
void shutdown_new_save_modes();
}

namespace {
// Provider settings are registered by mod_initialize, in user-defined load order.
bool s_itemSlotHooksInstalled = false;
}

extern "C" {

MOD_EXPORT ModResult mod_initialize(ModError* error) {
    (void)&mod_meta_import_svc_te_collection;
    (void)&mod_meta_import_svc_file;
    if (const ModResult result = dawnlight::register_config(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::initialize_save_state(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::register_ui(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::install_model_hooks(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::install_eye_movement_hooks(error); result != MOD_OK) {
        return result;
    }
    if (const auto result = dawnlight::initialize_progression(error); result != MOD_OK) {
        return result;
    }
    dawnlight::initialize_model_overlays();
    if (const ModResult result = dawnlight::initialize_bullet_time(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::initialize_bow_modes(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::initialize_great_spin_projectile(error);
        result != MOD_OK)
    {
        return result;
    }
    if (const ModResult result = dawnlight::initialize_fierce_deity(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::initialize_stamina(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::install_save_compat_hooks(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::install_aim_hooks(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::install_item_integrity_hooks(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::install_touch_button_hooks(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::install_collection_dual_wield(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::install_dual_wield_hooks(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::install_manual_shield_hooks(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::register_new_save_modes(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::initialize_survivors(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::initialize_epona_spurs_hud(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::initialize_hud_fade(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::initialize_fierce_deity_hud(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::initialize_gale_counter(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::install_jump_hooks(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::install_enemy_scaling_hooks(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::install_player_hard_mode_hooks(error);
        result != MOD_OK)
    {
        return result;
    }
    if (const ModResult result = dawnlight::install_cave_randomizer(error); result != MOD_OK) {
        return result;
    }
    if (const ModResult result = dawnlight::install_boss_hard_mode_hooks(error);
        result != MOD_OK)
    {
        return result;
    }
    if (const ModResult result = dawnlight::init_update_service(
            svc_log, mod_ctx, svc_ui, svc_config, dawnlight::check_for_updates_config_var());
        result != MOD_OK)
    {
        return result;
    }

    svc_log->info(mod_ctx, "Dawnlight portable feature pack initialized");
    return MOD_OK;
}

MOD_EXPORT ModResult mod_update(ModError* error) {
    // All mods have initialized before the first update, so saved provider
    // toggles are available even when Dawnlight is earlier in the load order.
    if (!s_itemSlotHooksInstalled) {
        if (const ModResult result = dawnlight::install_item_slot_hooks(error); result != MOD_OK) {
            return result;
        }
        s_itemSlotHooksInstalled = true;
    }
    dawnlight::update_cave_randomizer();
    dawnlight::update_new_save_modes();
    dawnlight::update_survivors();
    dawnlight::update_progression();
    dawnlight::update_collection_dual_wield();
    dawnlight::bullet_time_tick();
    dawnlight::update_stamina_ui();
    dawnlight::update_kh2_drive();
    dawnlight::update_update_service(svc_log, mod_ctx, svc_ui);
    return MOD_OK;
}

MOD_EXPORT ModResult mod_shutdown(ModError*) {
    s_itemSlotHooksInstalled = false;
    dawnlight::shutdown_survivors();
    dawnlight::shutdown_cave_randomizer();
    dawnlight::shutdown_collection_dual_wield();
    dawnlight::shutdown_dual_wield();
    dawnlight::shutdown_touch_buttons();
    dawnlight::shutdown_jump_hooks();
    dawnlight::shutdown_fierce_deity_hud();
    dawnlight::shutdown_hud_fade();
    dawnlight::shutdown_gale_counter();
    dawnlight::shutdown_model_overlays();
    dawnlight::shutdown_bow_modes();
    dawnlight::shutdown_great_spin_projectile();
    dawnlight::shutdown_fierce_deity();
    dawnlight::shutdown_bullet_time();
    dawnlight::shutdown_stamina();
    dawnlight::shutdown_new_save_modes();
    dawnlight::shutdown_progression();
    dawnlight::shutdown_save_state();
    dawnlight::shutdown_update_service();
    dawnlight::shutdown_item_slot_hooks();
    svc_log->info(mod_ctx, "Dawnlight portable feature pack stopped");
    return MOD_OK;
}

}  // extern "C"

#pragma once

#include "general_modes.hpp"
#include "jump_button.hpp"
#include "dual_wield_sword.hpp"
#include "stamina_settings.hpp"
#include "dark_link_settings.hpp"
#include "mods/api.h"
#include "mods/svc/config.h"

#include <string>

namespace dawnlight {

enum class BulletTimeMode : int { Off = 0, Always = 1, Botw = 2 };

enum class AimMode : int {
    Vanilla = 0,
    ThirdPerson = 1,
    Cinema = 2,
};

enum class NewSaveMode : int {
    Vanilla = 0,
    IntroSkip = 1,
};

enum class CustomModel : int {
    OrdonLink = 0,
    HeroClothes,
    ZoraArmor,
    MagicArmor,
    WolfLink,
    SumoLink,
    Horse,
    Items,
    Animations,
    OrdonShield,
    WoodenShield,
    HylianShield,
    Count,
};

enum class HudLayout : int {
    GameCube = 0,
    XBox = 1,
    WiiU = 2,
    Dawnlight = 3,
    Custom = 4,
};

enum class HudElement : int {
    A = 0,
    B,
    X,
    Y,
    Z,
    ButtonBacking,
    DPad,
    Midna,
    Hearts,
    Rupees,
    Keys,
    Oil,
    Oxygen,
    Minimap,
    DPadItemsText,
    DPadMapText,
    StaminaBar,
    FierceDeityBar,
    GaleCounter,
    TearsOfLight,
    EponaSpurs,
    Count,
};

enum class HudButton : int {
    A = 0,
    B,
    X,
    Y,
    Z,
    Count,
};

enum class HudSettingsIoResult {
    Ok,
    FileMissing,
    PathUnavailable,
    ReadFailed,
    WriteFailed,
    InvalidFormat,
    ConfigFailed,
};

ModResult register_owned_setting(const ConfigVarDesc* desc, ConfigVarHandle* handle);
HudSettingsIoResult export_all_settings(std::string& outPath);
HudSettingsIoResult import_all_settings_json(const std::string& json);
ModResult register_config(ModError* error);
bool dawnlight_mode_enabled();
bool edit_requires_progression_off(ConfigVarHandle var);
ModResult leave_dawnlight_mode_for_edit(ConfigVarHandle var);
bool progression_system_enabled();
bool notifications_enabled();
ConfigVarHandle dawnlight_mode_config_var();
ConfigVarHandle progression_system_config_var();
ConfigVarHandle notifications_config_var();
ModeSetting mode_setting_for_config(ConfigVarHandle var);
bool mode_config_override(ConfigVarHandle var, int64_t& value);
int health_scale_percent();
bool automatic_ngplus_health_scaling();
bool save_compatibility_enabled();
bool item_integrity_fixes_enabled();
NewSaveMode new_save_mode();
AimMode aim_mode();
bool aim_movement_enabled();
int cinema_zoom_percent();
int third_person_reticle_offset_y();
BulletTimeMode bullet_time_mode();
bool bullet_time_enabled();
bool flurry_rush_enabled();
enum class FierceDeityVisual : int { MagicArmor = 0, Dark = 1, DarkMagic = 2, White = 3, Gold = 4 };
bool fierce_deity_enabled();
bool dark_link_free_transform();
ConfigVarHandle dark_link_free_transform_config_var();
FierceDeityVisual fierce_deity_visual();
ConfigVarHandle fierce_deity_visual_config_var();
bool dark_link_aura_enabled();
ConfigVarHandle dark_link_aura_config_var();
enum class FierceDeityActivation : int { SpinAttack = 0, RZ = 1, RA = 2, L3 = 3, R3 = 4 };
FierceDeityActivation fierce_deity_activation();
int dark_link_setting(DarkLinkSetting setting);
ConfigVarHandle dark_link_setting_config_var(DarkLinkSetting setting);
ConfigVarHandle fierce_deity_activation_config_var();
bool great_spin_projectile_enabled();
bool dual_wield_enabled();
ConfigVarHandle dual_wield_config_var();
SecondSword second_sword();
ConfigVarHandle second_sword_config_var();
bool arrow_modes_enabled();
bool manual_shielding_enabled();
bool r_jump_enabled();
JumpButton jump_button();
bool disable_auto_jump_enabled();
float jump_height_multiplier();
float gale_height_bonus();
bool gale_counter_visible();
int gale_counter_capacity();
int gale_recovery_seconds();
bool glide_enabled();
enum class GlideItem { Cucco, Glider };
GlideItem glide_item();
bool revalis_gale_enabled();
bool stamina_enabled();
int stamina_setting(StaminaSetting setting);
ConfigVarHandle stamina_setting_config_var(StaminaSetting setting);
bool sprint_enabled();
bool wolf_sprint_enabled();
float wolf_speed_multiplier();
float sprint_speed_multiplier();
bool z_item_slot_enabled();
bool dawnlight_touch_ui_enabled();
bool check_for_updates_enabled();
bool enemy_hard_mode_enabled();
bool boss_rush_enabled();
bool clear_timer_enabled();
bool cave_boss_visits_enabled();
ConfigVarHandle cave_boss_visits_config_var();
ConfigVarHandle boss_rush_config_var();
ConfigVarHandle clear_timer_config_var();
bool cave_randomizer_enabled();
bool remove_normal_hit_invulnerability_enabled();
bool bossrush_hardmode_hazards_enabled();
bool hide_shield_enabled();
int eye_movement_range_percent();
bool custom_model_enabled(CustomModel model);
HudLayout hud_layout();
bool hardcoded_hud_layout_enabled();
bool custom_hud_layout_enabled();
bool round_xy_buttons_enabled();
bool hud_custom_button_backing_visible();
bool hud_auto_fade_enabled();
bool hud_custom_stamina_fade_when_full();
bool hud_custom_fierce_deity_fade_when_empty();
bool hud_custom_health_bar_enabled();
bool hud_custom_dpad_hide_arrows();
bool hud_custom_dpad_hide_shadows();
bool hud_button_backing_visible();
int hud_custom_element_x(HudElement element);
int hud_custom_element_y(HudElement element);
int hud_custom_element_scale_percent(HudElement element);
int hud_custom_button_item_offset_x(HudButton button);
int hud_custom_button_item_offset_y(HudButton button);
int hud_custom_button_item_scale_percent(HudButton button);
int hud_custom_button_ammo_offset_x(HudButton button);
int hud_custom_button_ammo_offset_y(HudButton button);
int hud_custom_button_ammo_scale_percent(HudButton button);
int hud_custom_button_text_offset_x(HudButton button);
int hud_custom_button_text_offset_y(HudButton button);
int hud_custom_button_text_scale_percent(HudButton button);
int hud_custom_button_item_anchor(HudButton button);
int hud_custom_button_text_anchor(HudButton button);
bool hud_custom_dpad_follows_minimap();
int hud_custom_minimap_slide_direction();

ConfigVarHandle health_scale_config_var();
ConfigVarHandle automatic_health_scale_config_var();
ConfigVarHandle save_compatibility_config_var();
ConfigVarHandle item_integrity_config_var();
ConfigVarHandle new_save_mode_config_var();
ConfigVarHandle aim_mode_config_var();
ConfigVarHandle aim_movement_config_var();
ConfigVarHandle cinema_zoom_config_var();
ConfigVarHandle third_person_reticle_offset_y_config_var();
ConfigVarHandle bullet_time_config_var();
ConfigVarHandle flurry_rush_config_var();
ConfigVarHandle fierce_deity_config_var();
ConfigVarHandle great_spin_projectile_config_var();
ConfigVarHandle arrow_modes_config_var();
ConfigVarHandle manual_shielding_config_var();
ConfigVarHandle r_jump_config_var();
ConfigVarHandle jump_button_config_var();
ConfigVarHandle disable_auto_jump_config_var();
ConfigVarHandle jump_height_config_var();
ConfigVarHandle gale_height_config_var();
ConfigVarHandle gale_counter_visible_config_var();
ConfigVarHandle gale_counter_capacity_config_var();
ConfigVarHandle gale_recovery_config_var();
ConfigVarHandle glide_config_var();
ConfigVarHandle glide_item_config_var();
ConfigVarHandle revalis_gale_config_var();
ConfigVarHandle stamina_config_var();
ConfigVarHandle sprint_config_var();
ConfigVarHandle wolf_sprint_config_var();
ConfigVarHandle wolf_speed_config_var();
ConfigVarHandle sprint_speed_config_var();
int enemy_spawner_profile();
ConfigVarHandle enemy_spawner_profile_config_var();
ConfigVarHandle z_item_slot_config_var();
ConfigVarHandle dawnlight_touch_ui_config_var();
ConfigVarHandle check_for_updates_config_var();
ConfigVarHandle enemy_hard_mode_config_var();
ConfigVarHandle cave_randomizer_config_var();
ConfigVarHandle remove_normal_hit_invulnerability_config_var();
ConfigVarHandle bossrush_hardmode_hazards_config_var();
ConfigVarHandle hide_shield_config_var();
ConfigVarHandle eye_movement_range_config_var();
ConfigVarHandle custom_model_config_var(CustomModel model);
ConfigVarHandle hud_layout_config_var();
ConfigVarHandle round_xy_buttons_config_var();
ConfigVarHandle hud_custom_button_backing_visible_config_var();
ConfigVarHandle hud_auto_fade_config_var();
ConfigVarHandle hud_custom_stamina_fade_when_full_config_var();
ConfigVarHandle hud_custom_fierce_deity_fade_when_empty_config_var();
ConfigVarHandle hud_custom_health_bar_config_var();
ConfigVarHandle hud_custom_dpad_hide_arrows_config_var();
ConfigVarHandle hud_custom_dpad_hide_shadows_config_var();
ConfigVarHandle hud_custom_element_x_config_var(HudElement element);
ConfigVarHandle hud_custom_element_y_config_var(HudElement element);
ConfigVarHandle hud_custom_element_scale_config_var(HudElement element);
ConfigVarHandle hud_custom_button_item_offset_x_config_var(HudButton button);
ConfigVarHandle hud_custom_button_item_offset_y_config_var(HudButton button);
ConfigVarHandle hud_custom_button_item_scale_config_var(HudButton button);
ConfigVarHandle hud_custom_button_ammo_offset_x_config_var(HudButton button);
ConfigVarHandle hud_custom_button_ammo_offset_y_config_var(HudButton button);
ConfigVarHandle hud_custom_button_ammo_scale_config_var(HudButton button);
ConfigVarHandle hud_custom_button_text_offset_x_config_var(HudButton button);
ConfigVarHandle hud_custom_button_text_offset_y_config_var(HudButton button);
ConfigVarHandle hud_custom_button_text_scale_config_var(HudButton button);
ConfigVarHandle hud_custom_button_item_anchor_config_var(HudButton button);
ConfigVarHandle hud_custom_button_text_anchor_config_var(HudButton button);
ConfigVarHandle hud_custom_dpad_follows_minimap_config_var();
ConfigVarHandle hud_custom_minimap_slide_direction_config_var();

HudSettingsIoResult export_custom_hud_settings(std::string& outPath);
HudSettingsIoResult import_custom_hud_settings(std::string& outPath);
HudSettingsIoResult import_custom_hud_settings_json(const std::string& json);
HudSettingsIoResult copy_hud_preset_to_custom(HudLayout layout);
HudSettingsIoResult reset_custom_hud_settings();
const char* hud_settings_io_result_message(HudSettingsIoResult result);

}  // namespace dawnlight

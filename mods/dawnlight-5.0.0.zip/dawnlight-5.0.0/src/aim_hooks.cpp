#include "platform_compat.hpp"
#include "aim_hooks.hpp"
#include "bullet_time.hpp"
#include "config.hpp"
#include "service_imports.hpp"

#include "global.h"
#include "d/actor/d_a_alink.h"
#include "d/actor/d_a_arrow.h"
#include "d/actor/d_a_boomerang.h"
#include "d/actor/d_a_obj_swhang.h"
#include "d/d_camera.h"
#include "d/d_com_inf_game.h"
#include "f_op/f_op_actor_iter.h"
#include "f_op/f_op_camera_mng.h"
#include "m_Do/m_Do_controller_pad.h"
#include "mods/hook.hpp"
#include "mods/service.hpp"
#include "mods/svc/hook.h"
#include "SSystem/SComponent/c_math.h"

#if !DAWNLIGHT_IOS && __has_include(<RmlUi/Core.h>) && __has_include(<SDL3/SDL_touch.h>) && \
    __has_include("dusk/ui/touch_controls.hpp")
#define DAWNLIGHT_HAS_PRIVATE_TOUCH_UI 1
#include <RmlUi/Core.h>
#include <SDL3/SDL_touch.h>
#else
#define DAWNLIGHT_HAS_PRIVATE_TOUCH_UI 0
#endif

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <string>

#if DAWNLIGHT_HAS_PRIVATE_TOUCH_UI
#define private public
#include "dusk/ui/touch_controls.hpp"
#undef private
#endif

namespace dawnlight {
namespace {

DEFINE_HOOK(&daAlink_c::procBowSubject, BowSubjectHook);
DEFINE_HOOK(&daAlink_c::procBoomerangSubject, BoomerangSubjectHook);
DEFINE_HOOK(&daAlink_c::procHookshotSubject, HookshotSubjectHook);
DEFINE_HOOK(&daAlink_c::procIronBallSubject, IronBallSubjectHook);
DEFINE_HOOK(&daAlink_c::procCopyRodSubject, CopyRodSubjectHook);
DEFINE_HOOK(&daAlink_c::execute, PlayerExecuteHook);
DEFINE_HOOK(&daAlink_c::modelCalc, BowModelCalcHook);
DEFINE_HOOK(&daArrow_c::arrowShooting, BowArrowShootingHook);
DEFINE_HOOK(&daAlink_c::setHookshotPos, HookshotPosHook);
DEFINE_HOOK(&dCamera_c::Run, CameraRunHook);
DEFINE_HOOK(&dCamera_c::subjectCamera, SubjectCameraHook);
DEFINE_HOOK(&dCamera_c::nextMode, CameraNextModeHook);
DEFINE_HOOK(&dCamera_c::nextType, CameraNextTypeHook);
#if DAWNLIGHT_HAS_PRIVATE_TOUCH_UI
#if defined(__ANDROID__)
#define DAWNLIGHT_TOUCH_SYNC_STATE_SYMBOL "_ZN4dusk2ui13TouchControls16sync_touch_stateEv"
#define DAWNLIGHT_TOUCH_HANDLE_DOWN_SYMBOL "_ZN4dusk2ui13TouchControls17handle_touch_downERN3Rml5EventE"
#elif defined(__linux__) || defined(__APPLE__)
#define DAWNLIGHT_TOUCH_SYNC_STATE_SYMBOL "_ZN4dusk2ui13TouchControls16sync_touch_stateEv"
#define DAWNLIGHT_TOUCH_HANDLE_DOWN_SYMBOL "_ZN4dusk2ui13TouchControls17handle_touch_downERN3Rml5EventE"
#else
#define DAWNLIGHT_TOUCH_SYNC_STATE_SYMBOL "dusk::ui::TouchControls::sync_touch_state"
#define DAWNLIGHT_TOUCH_HANDLE_DOWN_SYMBOL "dusk::ui::TouchControls::handle_touch_down"
#endif

DEFINE_HOOK_SYMBOL(DAWNLIGHT_TOUCH_SYNC_STATE_SYMBOL,
    void(dusk::ui::TouchControls*), TouchSyncStateHook);
DEFINE_HOOK_SYMBOL(DAWNLIGHT_TOUCH_HANDLE_DOWN_SYMBOL,
    void(dusk::ui::TouchControls*, Rml::Event*), TouchHandleDownHook);

constexpr float kTouchStickRadiusDp = 62.0f;
constexpr float kTouchStickKnobRadiusDp = 24.0f;
constexpr float kTouchAnalogZoneTopDp = 92.0f;
constexpr float kTouchAnalogZoneBottomDp = 30.0f;
constexpr float kTouchLeftZoneWidth = 0.46f;
constexpr float kTouchRightZoneStart = 0.52f;

#if defined(__ANDROID__)
constexpr const char* kTouchEventIdSymbol = "_ZN4dusk2ui14touch_event_idERKN3Rml5EventE";
constexpr const char* kTouchEventPositionSymbol =
    "_ZN4dusk2ui20touch_event_positionERKN3Rml5EventE";
constexpr const char* kTouchDpScaleSymbol = "_ZN4dusk2ui14touch_dp_scaleEPN3Rml7ContextE";
constexpr const char* kRmlContextSymbol = "_ZN6aurora5rmlui11get_contextEv";
constexpr const char* kRmlContextDimensionsSymbol = "_ZNK3Rml7Context13GetDimensionsEv";
constexpr const char* kRmlSetClassSymbol =
    "_ZN3Rml7Element8SetClassERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEb";
constexpr const char* kRmlSetPropertySymbol =
    "_ZN3Rml7Element11SetPropertyERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_";
#elif defined(__linux__)
constexpr const char* kTouchEventIdSymbol = "_ZN4dusk2ui14touch_event_idERKN3Rml5EventE";
constexpr const char* kTouchEventPositionSymbol =
    "_ZN4dusk2ui20touch_event_positionERKN3Rml5EventE";
constexpr const char* kTouchDpScaleSymbol = "_ZN4dusk2ui14touch_dp_scaleEPN3Rml7ContextE";
constexpr const char* kRmlContextSymbol = "_ZN6aurora5rmlui11get_contextEv";
constexpr const char* kRmlContextDimensionsSymbol = "_ZNK3Rml7Context13GetDimensionsEv";
constexpr const char* kRmlSetClassSymbol =
    "_ZN3Rml7Element8SetClassERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEEb";
constexpr const char* kRmlSetPropertySymbol =
    "_ZN3Rml7Element11SetPropertyERKNSt7__cxx1112basic_stringIcSt11char_traitsIcESaIcEEES8_";
#elif defined(__APPLE__)
constexpr const char* kTouchEventIdSymbol = "_ZN4dusk2ui14touch_event_idERKN3Rml5EventE";
constexpr const char* kTouchEventPositionSymbol =
    "_ZN4dusk2ui20touch_event_positionERKN3Rml5EventE";
constexpr const char* kTouchDpScaleSymbol = "_ZN4dusk2ui14touch_dp_scaleEPN3Rml7ContextE";
constexpr const char* kRmlContextSymbol = "_ZN6aurora5rmlui11get_contextEv";
constexpr const char* kRmlContextDimensionsSymbol = "_ZNK3Rml7Context13GetDimensionsEv";
constexpr const char* kRmlSetClassSymbol =
    "_ZN3Rml7Element8SetClassERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEEb";
constexpr const char* kRmlSetPropertySymbol =
    "_ZN3Rml7Element11SetPropertyERKNSt3__112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_";
#else
constexpr const char* kTouchEventIdSymbol = "dusk::ui::touch_event_id";
constexpr const char* kTouchEventPositionSymbol = "dusk::ui::touch_event_position";
constexpr const char* kTouchDpScaleSymbol = "dusk::ui::touch_dp_scale";
constexpr const char* kRmlContextSymbol = "aurora::rmlui::get_context";
constexpr const char* kRmlContextDimensionsSymbol = "Rml::Context::GetDimensions";
constexpr const char* kRmlSetClassSymbol = "Rml::Element::SetClass";
constexpr const char* kRmlSetPropertySymbol = "Rml::Element::SetProperty";
#endif
#endif

enum class AimItem {
    Bow,
    Boomerang,
    Hookshot,
    IronBall,
    CopyRod,
};

#if DAWNLIGHT_HAS_PRIVATE_TOUCH_UI
using TouchControls = dusk::ui::TouchControls;
using TouchEventIdFn = SDL_FingerID (*)(const Rml::Event&) noexcept;
using TouchEventPositionFn = Rml::Vector2f (*)(const Rml::Event&) noexcept;
using TouchDpScaleFn = float (*)(Rml::Context*) noexcept;
using RmlContextFn = Rml::Context* (*)();
using RmlContextDimensionsFn = Rml::Vector2i (*)(const Rml::Context*);
using RmlElementSetClassFn = void (*)(Rml::Element*, const Rml::String&, bool);
using RmlElementSetPropertyFn =
    bool (*)(Rml::Element*, const Rml::String&, const Rml::String&);

TouchEventIdFn s_touchEventId = nullptr;
TouchEventPositionFn s_touchEventPosition = nullptr;
TouchDpScaleFn s_touchDpScale = nullptr;
RmlContextFn s_rmlContext = nullptr;
RmlContextDimensionsFn s_rmlContextDimensions = nullptr;
RmlElementSetClassFn s_rmlSetClass = nullptr;
RmlElementSetPropertyFn s_rmlSetProperty = nullptr;

struct SavedTouchMove {
    TouchControls* controls = nullptr;
    TouchControls::StickTouch move;
    SDL_FingerID cameraId = 0;
    bool active = false;
    bool cameraWasActive = false;
};

SavedTouchMove s_savedTouchMove;
bool s_touchBulletTimeMoveActive = false;
#endif
bool s_customCinemaSightActive = false;
bool s_thirdPersonAimActive = false;
float s_thirdPersonDistance = 300.0f;
float s_thirdPersonFovy = 45.0f;
float s_thirdPersonHeight = 130.0f;

bool use_custom_aim_movement() {
    return aim_movement_enabled();
}

bool use_third_person_camera() {
    return aim_mode() == AimMode::ThirdPerson;
}

bool use_cinema_camera() {
    return aim_mode() == AimMode::Cinema;
}

bool clawshot_hanging(const daAlink_c* link) {
    if (link == nullptr) {
        return false;
    }

    switch (link->mProcID) {
    case daAlink_c::PROC_HOOKSHOT_ROOF_WAIT:
    case daAlink_c::PROC_HOOKSHOT_ROOF_SHOOT:
    case daAlink_c::PROC_HOOKSHOT_ROOF_BOOTS:
    case daAlink_c::PROC_HOOKSHOT_WALL_WAIT:
    case daAlink_c::PROC_HOOKSHOT_WALL_SHOOT:
        return true;
    default:
        return false;
    }
}

bool use_third_person_camera_for(daAlink_c* link) {
    return use_third_person_camera() && !clawshot_hanging(link);
}

bool use_cinema_camera_for(daAlink_c* link) {
    return use_cinema_camera() || (use_third_person_camera() && clawshot_hanging(link));
}

void remember_custom_cinema_sight() {
    if (use_cinema_camera() || use_third_person_camera()) {
        s_customCinemaSightActive = true;
    }
}

bool use_scope_suppress_camera() {
    return aim_mode() == AimMode::ThirdPerson || aim_mode() == AimMode::Cinema;
}

bool is_hawkeye_bow(daAlink_c* link) {
    return link != nullptr && link->mEquipItem == dItemNo_HAWK_ARROW_e;
}

bool hawkeye_active() noexcept {
    return dCamera_c::isAimActive() && dComIfGp_checkPlayerStatus0(0, 0x200000);
}

bool touch_aim_movement_enabled() {
    return aim_movement_enabled() && dCamera_c::isAimActive() && !hawkeye_active();
}

bool player_in_supported_aim_status(const u32 pad) {
    return dComIfGp_checkPlayerStatus0(pad, 0x1040) ||
           dComIfGp_checkPlayerStatus0(pad, 0x80000) ||
           dComIfGp_checkPlayerStatus0(pad, 0x80) ||
           dComIfGp_checkPlayerStatus0(pad, 0x4000) ||
           dComIfGp_checkPlayerStatus0(pad, 0x400);
}

template <typename Fn>
ModResult resolve_required_symbol(const char* symbol, Fn& out) {
    void* resolved = nullptr;
    const ModResult result = svc_hook->resolve(mod_ctx, symbol, &resolved, nullptr);
    if (result == MOD_OK) {
        out = reinterpret_cast<Fn>(resolved);
    }
    return result;
}

template <typename Fn>
void resolve_optional_symbol(const char* symbol, Fn& out) {
    void* resolved = nullptr;
    if (svc_hook->resolve(mod_ctx, symbol, &resolved, nullptr) == MOD_OK) {
        out = reinterpret_cast<Fn>(resolved);
    }
}

#if DAWNLIGHT_HAS_PRIVATE_TOUCH_UI
ModResult resolve_touch_aim_symbols() {
    if (s_touchEventId != nullptr) {
        return MOD_OK;
    }

    ModResult result = resolve_required_symbol(kTouchEventIdSymbol, s_touchEventId);
    if (result == MOD_OK) {
        result = resolve_required_symbol(kTouchEventPositionSymbol, s_touchEventPosition);
    }
    if (result == MOD_OK) {
        result = resolve_required_symbol(kTouchDpScaleSymbol, s_touchDpScale);
    }
    if (result == MOD_OK) {
        result = resolve_required_symbol(kRmlContextSymbol, s_rmlContext);
    }
    if (result == MOD_OK) {
        result = resolve_required_symbol(kRmlContextDimensionsSymbol, s_rmlContextDimensions);
    }
    resolve_optional_symbol(kRmlSetClassSymbol, s_rmlSetClass);
    resolve_optional_symbol(kRmlSetPropertySymbol, s_rmlSetProperty);
    return result;
}

float touch_dp_scale(Rml::Context* context) {
    return s_touchDpScale != nullptr ? std::max(s_touchDpScale(context), 1.0f) : 1.0f;
}

void set_touch_element_class(Rml::Element* element, const char* className, bool active) {
    if (element == nullptr || s_rmlSetClass == nullptr) {
        return;
    }

    const std::string classNameString = className;
    s_rmlSetClass(element, classNameString, active);
}

void set_touch_element_px(Rml::Element* element, const char* property, float value) {
    if (element == nullptr || s_rmlSetProperty == nullptr) {
        return;
    }

    char valueString[32] = {};
    std::snprintf(valueString, sizeof(valueString), "%.3fpx", value);
    const std::string propertyString = property;
    const std::string propertyValue = valueString;
    s_rmlSetProperty(element, propertyString, propertyValue);
}

Rml::Vector2f clamped_touch_stick_delta(
    const Rml::Vector2f start, const Rml::Vector2f current, const float radius) {
    Rml::Vector2f delta = current - start;
    const float length = std::sqrt(delta.x * delta.x + delta.y * delta.y);
    if (length > radius && radius > 0.0f) {
        delta *= radius / length;
    }
    return delta;
}

void sync_touch_move_stick_visual(TouchControls* controls) {
    if (controls == nullptr || !controls->mMoveTouch.active || controls->mControlStick == nullptr) {
        return;
    }

    Rml::Context* context = s_rmlContext != nullptr ? s_rmlContext() : nullptr;
    const float scale = touch_dp_scale(context);
    const float stickRadius = kTouchStickRadiusDp * scale;
    if (stickRadius <= 0.0f) {
        return;
    }

    const Rml::Vector2f delta = clamped_touch_stick_delta(
        controls->mMoveTouch.start, controls->mMoveTouch.current, stickRadius);
    const float knobRadius = kTouchStickKnobRadiusDp * scale;

    set_touch_element_class(controls->mControlStick, "active", true);
    set_touch_element_px(
        controls->mControlStick, "left", controls->mMoveTouch.start.x - stickRadius);
    set_touch_element_px(
        controls->mControlStick, "top", controls->mMoveTouch.start.y - stickRadius);
    set_touch_element_px(
        controls->mControlKnob, "left", stickRadius + delta.x - knobRadius);
    set_touch_element_px(
        controls->mControlKnob, "top", stickRadius + delta.y - knobRadius);
}

bool touch_context_bounds(Rml::Vector2i& dimensions, float& scale) {
    Rml::Context* context = s_rmlContext != nullptr ? s_rmlContext() : nullptr;
    if (context == nullptr || s_rmlContextDimensions == nullptr) {
        return false;
    }

    dimensions = s_rmlContextDimensions(context);
    scale = touch_dp_scale(context);
    return dimensions.x > 0 && dimensions.y > 0;
}
#endif

// Native subject yaw/pitch are relative to Link's magnetic surface, not world Y.
cXyz aim_vector_to_local(daAlink_c* link, cXyz vector) {
    if (link->checkMagneBootsOn()) {
        mDoMtx_multVecSR(link->getMagneBootsInvMtx(), &vector, &vector);
    }
    return vector;
}

cXyz aim_vector_to_world(daAlink_c* link, cXyz vector) {
    if (link->checkMagneBootsOn()) {
        mDoMtx_multVecSR(link->getMagneBootsMtx(), &vector, &vector);
    }
    return vector;
}

BOOL face_camera_view_yaw(daAlink_c* link) {
    if (link == nullptr) {
        return FALSE;
    }

    auto* camera = dComIfGp_getCamera(link->field_0x317c);
    if (camera == nullptr) {
        return FALSE;
    }

    const cXyz direction = aim_vector_to_local(
        link, *fopCamM_GetCenter_p(camera) - *fopCamM_GetEye_p(camera));
    const f32 horizontal = JMAFastSqrt(SQUARE(direction.x) + SQUARE(direction.z));
    if (horizontal <= 0.001f) {
        return FALSE;
    }

    link->shape_angle.y = cM_atan2s(direction.x, direction.z);
    link->field_0x310c = link->shape_angle.y;
    return TRUE;
}

BOOL aim_with_c_stick(daAlink_c* link) {
    const f32 stickValue = link->mStickValue;
    const f32 moveValue = link->mMoveValue;
    const s16 stickAngle = link->mStickAngle;
    const s16 moveAngle = link->mMoveAngle;

    const f32 cStickValue = cLib_minMaxLimit<f32>(mDoCPd_c::getSubStickValue(PAD_1), 0.0f, 1.0f);
    if (cStickValue <= 0.05f) {
        link->mStickValue = 0.0f;
        link->mMoveValue = 0.0f;
    } else {
        link->mStickValue = cStickValue;
        link->mMoveValue = cStickValue;
        link->mStickAngle = mDoCPd_c::getSubStickAngle(PAD_1) + 0x8000;
        link->mMoveAngle = link->mStickAngle +
            dCam_getControledAngleY(dComIfGp_getCamera(link->field_0x317c));
    }

    const BOOL result = link->setBodyAngleToCamera();
    link->mStickValue = stickValue;
    link->mMoveValue = moveValue;
    link->mStickAngle = stickAngle;
    link->mMoveAngle = moveAngle;
    return result;
}

void update_move_animation(daAlink_c* link, u8 waitDirection, bool rightWait, bool ironBall) {
    f32 morph = -1.0f;
    if (link->checkZeroSpeedF()) {
        link->onModeFlg(1);
        if (link->field_0x2f98 != waitDirection) {
            link->field_0x2f98 = waitDirection;
        }
        if (rightWait) {
            link->current.angle.y = link->shape_angle.y - 0x4000;
        }
    } else {
        link->offModeFlg(1);
    }

    if (ironBall && link->checkModeFlg(1)) {
        link->setIronBallBaseAnime();
    } else {
        link->setBlendAtnMoveAnime(morph);
    }
}

void draw_iron_ball_sight(daAlink_c* link) {
    cXyz position;
    link->checkSightLine(10000.0f, &position);
    link->mSight.setPos(&position);
    link->mSight.onDrawFlg();
    link->mSight.offLockFlg();
    remember_custom_cinema_sight();
}

void draw_camera_center_sight(daAlink_c* link) {
    auto* camera = link != nullptr ? dComIfGp_getCamera(link->field_0x317c) : nullptr;
    if (camera == nullptr) {
        return;
    }

    cXyz* eye = fopCamM_GetEye_p(camera);
    cXyz* center = fopCamM_GetCenter_p(camera);
    cXyz direction = *center - *eye;
    if (direction.abs() <= 0.001f) {
        return;
    }

    direction.normalize();
    cXyz position = *eye + direction * 10000.0f;
    link->mArrowLinChk.Set(eye, &position, link);
    if (dComIfG_Bgsp().LineCross(&link->mArrowLinChk)) {
        position = link->mArrowLinChk.GetCross();
    }

    link->mSight.setPos(&position);
    link->mSight.onDrawFlg();
    link->mSight.offLockFlg();
    remember_custom_cinema_sight();
}

bool fixed_bow_aim_active(daAlink_c* link) {
    return link != nullptr && use_scope_suppress_camera() &&
        daAlink_c::checkBowItem(link->mEquipItem) && !is_hawkeye_bow(link) &&
        !link->checkWolf() && !link->checkAttentionLock() && !link->checkEventRun() &&
        (dComIfGp_checkPlayerStatus0(0, 0x1000) || bullet_time_active_for(link));
}

bool custom_slingshot_sight_active(daAlink_c* link) {
    // Sight only: keep the Slingshot out of the Bow pose/arrow correction hooks.
    return link != nullptr && use_scope_suppress_camera() &&
        link->mEquipItem == dItemNo_PACHINKO_e &&
        !link->checkWolf() && !link->checkAttentionLock() && !link->checkEventRun() &&
        dComIfGp_checkPlayerStatus0(0, 0x40);
}

bool fixed_clawshot_aim_active(daAlink_c* link) {
    return link != nullptr && use_scope_suppress_camera() &&
        link->checkHookshotItem(link->mEquipItem) && !link->checkWolf() &&
        !link->checkAttentionLock() && !link->checkEventRun();
}

bool fixed_camera_sight_active(daAlink_c* link) {
    return link != nullptr && use_scope_suppress_camera() &&
        (link->checkHookshotItem(link->mEquipItem) || link->checkIronBallEquip() ||
            link->checkCopyRodEquip() || link->mEquipItem == dItemNo_BOOMERANG_e) &&
        !link->checkWolf() && !link->checkAttentionLock() && !link->checkEventRun();
}

struct HookshotActorTarget {
    daAlink_c* link = nullptr;
    fopAc_ac_c* actor = nullptr;
    cXyz eye;
    cXyz forward;
    cXyz position;
    f32 backgroundDistance = 0.0f;
    f32 maxLength = 0.0f;
    f32 bestPerpendicularDistanceSq = 0.0f;
    f32 bestForwardDistance = 0.0f;
    bool found = false;
};

bool is_custom_hookshot_target(fopAc_ac_c* actor) {
    if (actor == nullptr || fopAcM_GetName(actor) != fpcNm_Obj_SwHang_e) {
        return false;
    }

    const int type = static_cast<daObjSwHang_c*>(actor)->getType();
    return type == daObjSwHang_c::TYPE_3 || type == daObjSwHang_c::TYPE_4;
}

int find_hookshot_actor_target(void* actorPtr, void* dataPtr) {
    auto* actor = static_cast<fopAc_ac_c*>(actorPtr);
    auto* query = static_cast<HookshotActorTarget*>(dataPtr);
    if (actor == nullptr || query == nullptr || actor == query->link ||
        !is_custom_hookshot_target(actor)) {
        return 0;
    }

    // Obj_SwHang types 3/4 use a large Clawshot sphere above mHangPos.
    // Other variants either use different interaction rules or do not
    // register this sphere, so they must stay on Vanilla's targeting path.
    auto* switchHang = static_cast<daObjSwHang_c*>(actor);
    const cXyz targetPosition = switchHang->mCcSph.GetC();
    const f32 targetRadius = switchHang->mCcSph.GetR();

    const cXyz toTarget = targetPosition - query->eye;
    const f32 forwardDistance = toTarget.inprod(query->forward);
    if (forwardDistance <= 0.0f ||
        forwardDistance - targetRadius > query->backgroundDistance ||
        (targetPosition - query->link->mHeldItemRootPos).abs() - targetRadius >
            query->maxLength) {
        return 0;
    }

    const f32 perpendicularDistanceSq =
        std::max(0.0f, toTarget.inprod(toTarget) - forwardDistance * forwardDistance);
    if (perpendicularDistanceSq > targetRadius * targetRadius ||
        (query->found &&
            (perpendicularDistanceSq > query->bestPerpendicularDistanceSq ||
                (perpendicularDistanceSq == query->bestPerpendicularDistanceSq &&
                    forwardDistance >= query->bestForwardDistance)))) {
        return 0;
    }

    // Vanilla detects the collision volume but aims the sight and the launched
    // Clawshot at the actor's eye position.  For Obj_SwHang this is mHangPos,
    // the visible grab point below the sphere, and avoids shooting into the
    // solid cage geometry around the collision-volume center.
    query->position = actor->eyePos;
    query->actor = actor;
    query->bestPerpendicularDistanceSq = perpendicularDistanceSq;
    query->bestForwardDistance = forwardDistance;
    query->found = true;
    return 0;
}

bool camera_aim_ray(daAlink_c* link, cXyz& eye, cXyz& forward) {
    if (link == nullptr) return false;
    auto* actor = dComIfGp_getCamera(link->field_0x317c);
    if (actor == nullptr) return false;
    return third_person_reticle_ray(&actor->mCamera,
        use_third_person_camera_for(link) ? third_person_reticle_offset_y() : 0,
        s_thirdPersonFovy, eye, forward);
}

bool camera_bow_target(daAlink_c* link, cXyz& target, cXyz& forward,
    fopAc_ac_c** hookshotActorTarget = nullptr) {
    if (hookshotActorTarget != nullptr) {
        *hookshotActorTarget = nullptr;
    }
    cXyz eye;
    if (!camera_aim_ray(link, eye, forward)) return false;
    target = eye + forward * 10000.0f;
    if (link->checkHookshotItem(link->mEquipItem)) {
        // Clawshot targets can use polygons which arrows deliberately pass
        // through (for example City in the Sky's L7HsMato targets).
        link->mRopeLinChk.Set(&eye, &target, link);
        if (dComIfG_Bgsp().LineCross(&link->mRopeLinChk)) {
            target = link->mRopeLinChk.GetCross();
        }

        HookshotActorTarget query;
        query.link = link;
        query.eye = eye;
        query.forward = forward;
        query.backgroundDistance = (target - eye).abs();
        query.maxLength = link->checkLv7BossRoom()
            ? link->mpHIO->mItem.mHookshot.m.mBossMaxLength
            : link->mpHIO->mItem.mHookshot.m.mMaxLength;
        fopAcIt_Executor(find_hookshot_actor_target, &query);
        if (query.found) {
            target = query.position;
            if (hookshotActorTarget != nullptr) {
                *hookshotActorTarget = query.actor;
            }
        }
    } else {
        dBgS_ArrowLinChk line;
        line.Set(&eye, &target, link);
        if (dComIfG_Bgsp().LineCross(&line)) {
            target = line.GetCross();
        }
    }
    return true;
}

bool bow_target_direction(const cXyz& origin, const cXyz& target,
    const cXyz& cameraForward, cXyz& direction);

void draw_boomerang_camera_sight(daAlink_c* link) {
    if (link == nullptr || link->mItemAcKeep.getActor() == nullptr ||
        link->checkBoomerangThrowAnime()) {
        return;
    }

    cXyz eye, forward;
    if (!camera_aim_ray(link, eye, forward)) return;

    // Preserve setBoomerangSight's gameplay side effects, not just its cursor.
    // Terrain locks use the boomerang-specific polygon filter and native range.
    cXyz target = eye + forward * link->getBoomLockMax();
    link->mBoomerangLinChk.Set(&eye, &target, link);
    const bool backgroundHit = dComIfG_Bgsp().LineCross(&link->mBoomerangLinChk);
    link->offResetFlg0(daPy_py_c::RFLG0_ITEM_SIGHT_BG_HIT);
    if (backgroundHit) {
        target = link->mBoomerangLinChk.GetCross();
        link->onResetFlg0(daPy_py_c::RFLG0_ITEM_SIGHT_BG_HIT);
    }

    // procWait consumes this position and the background-hit flag on lock input.
    link->mHeldItemRootPos = target;
    link->mSight.setPos(&target);
    link->mSight.onDrawFlg();
    auto* boomerang = static_cast<daBoomerang_c*>(link->mItemAcKeep.getActor());
    if (boomerang->getLockReserve() || (backgroundHit && !boomerang->getLockCntMax())) {
        link->setItemActionButtonStatus(BUTTON_STATUS_LOCK);
        link->itemActionTrigger();
    }
    remember_custom_cinema_sight();
}

void draw_fixed_camera_sight(daAlink_c* link) {
    if (link == nullptr) {
        return;
    }

    if (link->mEquipItem == dItemNo_BOOMERANG_e) {
        draw_boomerang_camera_sight(link);
        return;
    }

    const bool hookshot = link->checkHookshotItem(link->mEquipItem);
    if (hookshot && !link->checkHookshotWait()) {
        link->mSight.offDrawFlg();
        return;
    }

    cXyz target, forward;
    fopAc_ac_c* hookshotActorTarget = nullptr;
    if (!camera_bow_target(link, target, forward, &hookshotActorTarget)) {
        return;
    }

    if (hookshot) {
        cXyz direction;
        if (bow_target_direction(link->mHeldItemRootPos, target, forward, direction)) {
            const csXyz bodyAngle = link->mBodyAngle;
            link->mBodyAngle.x = cM_atan2s(-direction.y, direction.absXZ());
            link->mBodyAngle.y = cM_atan2s(direction.x, direction.z) - link->shape_angle.y;
            // Feed actor targets through Vanilla's keep object before asking
            // Vanilla to update the reticle.  Besides selecting the yellow
            // cursor, this avoids repeatedly restarting its intro animation.
            if (hookshotActorTarget != nullptr) {
                link->mHookTargetAcKeep.setData(hookshotActorTarget);
            } else if (is_custom_hookshot_target(link->mHookTargetAcKeep.getActor())) {
                // Drop only a target injected by this custom ray. A different
                // actor may have been supplied by Vanilla's collision pass.
                link->mHookTargetAcKeep.clearData();
            }
            link->setHookshotSight();
            link->mBodyAngle = bodyAngle;

            // setHookshotSight() deliberately clears this each frame after it
            // has drawn the cursor.  Retain the selected actor so the release
            // frame can enter the normal HookCarry/attachment path.
            if (hookshotActorTarget != nullptr) {
                link->mHookTargetAcKeep.setData(hookshotActorTarget);
            }
        } else {
            link->mHookTargetAcKeep.clearData();
            link->mSight.offLockFlg();
        }
    } else {
        link->mSight.offLockFlg();
    }

    link->mSight.setPos(&target);
    link->mSight.onDrawFlg();
    remember_custom_cinema_sight();
}

bool bow_launch_position(daAlink_c* link, cXyz& origin) {
    // Query the aimed launch point without changing gameplay's item position.
    const cXyz savedRoot = link->mHeldItemRootPos;
    s16 pitch;
    s16 yaw;
    const cXyz* launchPosition = link->checkBowCameraArrowPosP(&pitch, &yaw);
    if (launchPosition != nullptr) {
        origin = *launchPosition;
    }
    link->mHeldItemRootPos = savedRoot;
    return launchPosition != nullptr;
}

bool bow_target_direction(const cXyz& origin, const cXyz& target,
    const cXyz& cameraForward, cXyz& direction) {
    direction = target - origin;
    // Do not shoot backwards when the camera is blocked behind Link.
    if (direction.abs() <= 0.001f || direction.inprod(cameraForward) <= 0.0f) return false;
    direction.normalize();
    return true;
}

struct BowPoseCorrection {
    daAlink_c* link = nullptr;
    csXyz bodyAngle;
    s16 torsoYaw = 0;
};
BowPoseCorrection s_bowPose;

HookAction before_bow_model_calc(ModContext*, void* args, void*, void*) {
    auto* link = mods::arg<daAlink_c*>(args, 0);
    auto* model = mods::arg<J3DModel*>(args, 1);
    if (!fixed_bow_aim_active(link) || model != link->mpLinkModel || s_bowPose.link != nullptr) {
        return HOOK_CONTINUE;
    }
    cXyz target, forward, origin, direction;
    if (!camera_bow_target(link, target, forward) || !bow_launch_position(link, origin) ||
        !bow_target_direction(origin, target, forward, direction)) return HOOK_CONTINUE;
    if (link->checkMagneBootsOn()) {
        mDoMtx_multVecSR(link->getMagneBootsInvMtx(), &direction, &direction);
    }
    s_bowPose = {link, link->mBodyAngle, link->field_0x30c8};
    link->mBodyAngle.x = cM_atan2s(-direction.y, direction.absXZ());
    link->mBodyAngle.y = cM_atan2s(direction.x, direction.z) - link->shape_angle.y;
    link->field_0x30c8 = link->mBodyAngle.y >> 1;
    return HOOK_CONTINUE;
}

void after_bow_model_calc(ModContext*, void* args, void*, void*) {
    auto* link = mods::arg<daAlink_c*>(args, 0);
    if (s_bowPose.link != link || link == nullptr ||
        mods::arg<J3DModel*>(args, 1) != link->mpLinkModel) return;
    // Only the model receives parallax correction; input and camera angles do not.
    link->mBodyAngle = s_bowPose.bodyAngle;
    link->field_0x30c8 = s_bowPose.torsoYaw;
    s_bowPose = {};
}

struct ClawshotAimCorrection {
    daAlink_c* link = nullptr;
    csXyz bodyAngle;
    cXyz direction;
};
ClawshotAimCorrection s_clawshotAim;

HookAction before_hookshot_pos(ModContext*, void* args, void*, void*) {
    auto* link = mods::arg<daAlink_c*>(args, 0);
    // Actor hook points (for example Obj_SwHang ceiling switches) are found by
    // the ready-state attack capsule. Keep that capsule on the custom camera
    // ray while aiming as well as when the clawshot is released.
    if (!fixed_clawshot_aim_active(link) ||
        (!link->checkHookshotWait() && link->mItemMode != 2) ||
        s_clawshotAim.link != nullptr) {
        return HOOK_CONTINUE;
    }

    cXyz target, forward, direction;
    fopAc_ac_c* hookshotActorTarget = nullptr;
    if (!camera_bow_target(link, target, forward, &hookshotActorTarget) ||
        !bow_target_direction(link->mHeldItemRootPos, target, forward, direction)) {
        return HOOK_CONTINUE;
    }

    if (hookshotActorTarget != nullptr) {
        // checkUpperItemActionHookshot() clears the ready-state actor exactly
        // when it changes mItemMode to the release state.  Restore it here,
        // after that transition and before Vanilla captures the shot target.
        link->mHookTargetAcKeep.setData(hookshotActorTarget);
        link->field_0x381c = hookshotActorTarget->eyePos;
    }

    s_clawshotAim = {link, link->mBodyAngle, direction};
    link->mBodyAngle.x = cM_atan2s(-direction.y, direction.absXZ());
    link->mBodyAngle.y = cM_atan2s(direction.x, direction.z) - link->shape_angle.y;
    return HOOK_CONTINUE;
}

void after_hookshot_pos(ModContext*, void* args, void*, void*) {
    auto* link = mods::arg<daAlink_c*>(args, 0);
    if (s_clawshotAim.link != link || link == nullptr) return;
    // setHookshotPos derives this vector from several animation/body angles.
    // Keep the actual launch and ready-state collision capsule on the exact
    // custom-camera ray, independent of later pose adjustments.
    link->mIronBallCenterPos = s_clawshotAim.direction;
    link->field_0x301c = cM_atan2s(-s_clawshotAim.direction.y,
        s_clawshotAim.direction.absXZ());
    link->field_0x301e = cM_atan2s(s_clawshotAim.direction.x,
        s_clawshotAim.direction.z);
    link->mBodyAngle = s_clawshotAim.bodyAngle;
    s_clawshotAim = {};
}

void after_bow_arrow_shooting(ModContext*, void* args, void*, void*) {
    auto* arrow = mods::arg<daArrow_c*>(args, 0);
    auto* link = daAlink_getAlinkActorClass();
    if (arrow != nullptr && fixed_bow_aim_active(link) &&
        (arrow->mArrowType == daArrow_c::ARROW_TYPE_NORMAL ||
            arrow->mArrowType == daArrow_c::ARROW_TYPE_BOMB)) {
        cXyz target, forward, direction;
        if (camera_bow_target(link, target, forward) &&
            bow_target_direction(arrow->current.pos, target, forward, direction)) {
            const f32 speedMagnitude = arrow->speed.abs();
            if (speedMagnitude <= 0.001f) return;
            // Run after vanilla has selected the final charge launch position,
            // but before setArrowAt registers the initial hit capsule.
            arrow->current.angle.x = cM_atan2s(direction.y, direction.absXZ());
            arrow->current.angle.y = cM_atan2s(direction.x, direction.z);
            arrow->shape_angle.x = -arrow->current.angle.x;
            arrow->shape_angle.y = arrow->current.angle.y;
            arrow->speed = direction * speedMagnitude;
        }
    }
}

void draw_bow_trajectory_sight(daAlink_c* link) {
    if (link == nullptr) {
        return;
    }

    if (fixed_bow_aim_active(link)) {
        cXyz target, forward;
        if (camera_bow_target(link, target, forward)) {
            link->mSight.setPos(&target);
            link->mSight.onDrawFlg();
            link->mSight.offLockFlg();
            remember_custom_cinema_sight();
        }
        return;
    }

    f32 distance;
    f32 speed;
    link->getArrowFlyData(&distance, &speed, TRUE);

    cXyz position;
    link->checkSightLine(distance, &position);
    link->mSight.setPos(&position);
    link->mSight.onDrawFlg();
    link->mSight.offLockFlg();
    remember_custom_cinema_sight();
}

void draw_subject_sight(daAlink_c* link, AimItem item) {
    switch (item) {
    case AimItem::Bow:
        if (link->mEquipItem != dItemNo_HAWK_ARROW_e) {
            link->setBowSight();
            // Vanilla setBowSight already honors Dusklight's reticle setting.
            if (use_scope_suppress_camera()) {
                link->mSight.onDrawFlg();
            }
            remember_custom_cinema_sight();
        }
        break;
    case AimItem::Boomerang:
        if (fixed_camera_sight_active(link)) {
            draw_fixed_camera_sight(link);
        } else {
            link->setBoomerangSight();
            link->mSight.onDrawFlg();
            remember_custom_cinema_sight();
        }
        break;
    case AimItem::Hookshot:
        if (fixed_clawshot_aim_active(link)) {
            draw_fixed_camera_sight(link);
        } else {
            link->setHookshotSight();
            link->mSight.onDrawFlg();
            remember_custom_cinema_sight();
        }
        break;
    case AimItem::IronBall:
        if (fixed_camera_sight_active(link)) {
            draw_fixed_camera_sight(link);
        } else {
            draw_iron_ball_sight(link);
        }
        break;
    case AimItem::CopyRod:
        if (fixed_camera_sight_active(link)) {
            draw_fixed_camera_sight(link);
        } else {
            link->setCopyRodSight();
            link->mSight.onDrawFlg();
            remember_custom_cinema_sight();
        }
        break;
    }
}

bool should_keep_cinema_bow_sight(daAlink_c* link) {
    return link != nullptr && use_scope_suppress_camera() && !is_hawkeye_bow(link);
}

void keep_cinema_bow_sight(daAlink_c* link) {
    if (should_keep_cinema_bow_sight(link)) {
        if (aim_movement_enabled() && use_cinema_camera_for(link)) {
            aim_with_c_stick(link);
        }
        draw_camera_center_sight(link);
    }
}

void normalize_forward_aim_speed(daAlink_c* link) {
    if (link == nullptr || !use_custom_aim_movement() || link->mTargetedActor != nullptr ||
        !link->checkInputOnR())
    {
        return;
    }

    const s16 moveDelta = link->mMoveAngle - link->shape_angle.y;
    if (cM_scos(moveDelta) < 0.99f || std::fabs(cM_ssin(moveDelta)) > 0.02f) {
        return;
    }

    const f32 targetSpeed = link->mMaxSpeed * link->mStickValue * link->mStickValue;
    if (link->mNormalSpeed >= 0.0f && link->mNormalSpeed < targetSpeed) {
        link->mNormalSpeed = targetSpeed;
    }
}

void prepare_third_person_aim(daAlink_c* link) {
    if (link == nullptr || !use_third_person_camera_for(link) || is_hawkeye_bow(link) ||
        s_thirdPersonAimActive)
    {
        return;
    }
    auto* actor = dComIfGp_getCamera(link->field_0x317c);
    if (actor == nullptr || !face_camera_view_yaw(link)) {
        return;
    }

    auto& camera = actor->mCamera;
    const cXyz direction = aim_vector_to_local(link, camera.mCenter - camera.mEye);
    link->mBodyAngle.x = cM_atan2s(-direction.y, direction.absXZ());
    link->checkBodyAngleX(link->mBodyAngle.x);
    link->field_0x310a = link->mBodyAngle.x;
    s_thirdPersonDistance = std::clamp(direction.abs(), 200.0f, 600.0f);
    s_thirdPersonFovy = camera.mFovy;
    const cXyz centerOffset = aim_vector_to_local(link, camera.mCenter - link->current.pos);
    s_thirdPersonHeight = std::clamp(centerOffset.y, 100.0f, 180.0f);
    s_thirdPersonAimActive = true;
}

bool update_subject_aim(daAlink_c* link, AimItem item) {
    if (link == nullptr) {
        return false;
    }

    const bool hawkeyeBow = item == AimItem::Bow && is_hawkeye_bow(link);
    prepare_third_person_aim(link);
    if (hawkeyeBow || !use_custom_aim_movement()) {
        return false;
    }

    if (use_cinema_camera_for(link)) {
        face_camera_view_yaw(link);
    }

    const s16 shapeYaw = link->shape_angle.y;
    link->setSpeedAndAngleAtn();
    link->shape_angle.y = shapeYaw;

    switch (item) {
    case AimItem::Bow:
        update_move_animation(link, 3, true, false);
        if (aim_with_c_stick(link)) {
            draw_subject_sight(link, item);
        } else if (should_keep_cinema_bow_sight(link)) {
            draw_camera_center_sight(link);
        }
        break;
    case AimItem::Boomerang:
        update_move_animation(link, 3, false, false);
        if (aim_with_c_stick(link)) {
            draw_subject_sight(link, item);
        }
        break;
    case AimItem::Hookshot:
        if (link->checkHookshotWait()) {
            update_move_animation(link, 2, false, false);
            if (aim_with_c_stick(link)) {
                draw_subject_sight(link, item);
            }
        }
        break;
    case AimItem::IronBall:
        if (link->checkIronBallPreSwingAnime()) {
            link->mNormalSpeed = 0.0f;
        }
        update_move_animation(link, 2, false, true);
        if (link->itemButton() && link->mItemVar0.field_0x3018 == 2 && aim_with_c_stick(link)) {
            draw_iron_ball_sight(link);
        }
        break;
    case AimItem::CopyRod:
        update_move_animation(link, 3, false, false);
        if (aim_with_c_stick(link)) {
            draw_subject_sight(link, item);
        }
        break;
    }
    normalize_forward_aim_speed(link);
    return true;
}

#if DAWNLIGHT_HAS_PRIVATE_TOUCH_UI
HookAction before_touch_sync_state(ModContext*, void* args, void*, void*) {
    s_savedTouchMove = {};
    auto* controls = mods::arg<TouchControls*>(args, 0);
    auto* link = daAlink_getAlinkActorClass();
    s_touchBulletTimeMoveActive =
        controls != nullptr && !controls->mWasSuppressed && controls->mMoveTouch.active &&
        link != nullptr && bullet_time_active_for(link);
    if (!touch_aim_movement_enabled() || controls == nullptr || !controls->mMoveTouch.active) {
        return HOOK_CONTINUE;
    }

    s_savedTouchMove = {
        .controls = controls,
        .move = controls->mMoveTouch,
        .cameraId = controls->mCameraTouch.id,
        .active = true,
        .cameraWasActive = controls->mCameraTouch.active,
    };
    return HOOK_CONTINUE;
}

void after_touch_sync_state(ModContext*, void* args, void*, void*) {
    auto* controls = mods::arg<TouchControls*>(args, 0);
    const bool restore =
        s_savedTouchMove.active && s_savedTouchMove.controls == controls &&
        touch_aim_movement_enabled();
    if (!restore) {
        s_savedTouchMove = {};
        return;
    }

    if (!controls->mMoveTouch.active) {
        controls->mMoveTouch = s_savedTouchMove.move;
    }
    if (!s_savedTouchMove.cameraWasActive && controls->mCameraTouch.active &&
        controls->mCameraTouch.id == s_savedTouchMove.move.id)
    {
        controls->mCameraTouch = {};
    }

    sync_touch_move_stick_visual(controls);
    s_savedTouchMove = {};
}

HookAction before_touch_handle_down(ModContext*, void* args, void*, void*) {
    auto* controls = mods::arg<TouchControls*>(args, 0);
    auto* event = mods::arg<Rml::Event*>(args, 1);
    if (!touch_aim_movement_enabled() || controls == nullptr || event == nullptr ||
        controls->mWasSuppressed || s_touchEventId == nullptr || s_touchEventPosition == nullptr)
    {
        return HOOK_CONTINUE;
    }

    Rml::Vector2i dimensions;
    float scale = 1.0f;
    if (!touch_context_bounds(dimensions, scale)) {
        return HOOK_CONTINUE;
    }

    const Rml::Vector2f position = s_touchEventPosition(*event);
    const float width = static_cast<float>(dimensions.x);
    const bool inLeftZone = position.x < width * kTouchLeftZoneWidth;
    const bool inCameraZone = position.x > width * kTouchRightZoneStart;
    if (inCameraZone) {
        return HOOK_CONTINUE;
    }

    const float top = controls->mSafeInsets.top + kTouchAnalogZoneTopDp * scale;
    const float bottom =
        static_cast<float>(dimensions.y) - controls->mSafeInsets.bottom -
        kTouchAnalogZoneBottomDp * scale;
    const bool inAnalogZone = position.y >= top && position.y <= bottom;
    if (!inLeftZone || !inAnalogZone) {
        return HOOK_SKIP_ORIGINAL;
    }

    if (!controls->mMoveTouch.active) {
        controls->mMoveTouch = {
            .id = s_touchEventId(*event),
            .start = position,
            .current = position,
            .active = true,
        };
        sync_touch_move_stick_visual(controls);
    }
    return HOOK_SKIP_ORIGINAL;
}
#endif

HookAction replace_bow_subject(ModContext*, void* args, void* retval, void*) {
    auto* link = mods::arg<daAlink_c*>(args, 0);
    link->setDoStatus(BUTTON_STATUS_BACK);
    if (!link->checkNextAction(0) &&
        (!update_subject_aim(link, AimItem::Bow) && link->setBodyAngleToCamera()))
    {
        link->setBowSight();
    }
    keep_cinema_bow_sight(link);
    *static_cast<int*>(retval) = 1;
    return HOOK_SKIP_ORIGINAL;
}

HookAction replace_boomerang_subject(ModContext*, void* args, void* retval, void*) {
    auto* link = mods::arg<daAlink_c*>(args, 0);
    if (!link->checkItemActorPointer()) {
        *static_cast<int*>(retval) = 1;
        return HOOK_SKIP_ORIGINAL;
    }

    if (link->checkBoomerangReadyAnime()) {
        link->setDoStatus(BUTTON_STATUS_BACK);
    }
    link->setShapeAngleToAtnActor(0);

    if (!link->checkNextAction(0)) {
        if (!update_subject_aim(link, AimItem::Boomerang) && link->setBodyAngleToCamera()) {
            if (fixed_camera_sight_active(link)) {
                draw_fixed_camera_sight(link);
            } else {
                link->setBoomerangSight();
            }
        }
    } else {
        link->mSight.offDrawFlg();
    }

    *static_cast<int*>(retval) = 1;
    return HOOK_SKIP_ORIGINAL;
}

HookAction replace_hookshot_subject(ModContext*, void* args, void* retval, void*) {
    auto* link = mods::arg<daAlink_c*>(args, 0);
    if (link->checkHookshotWait()) {
        link->setDoStatus(BUTTON_STATUS_BACK);
    }

    link->setShapeAngleToAtnActor(0);
    link->mSight.offDrawFlg();

    if (!link->checkNextAction(0)) {
        if (link->checkHookshotWait()) {
            if (!update_subject_aim(link, AimItem::Hookshot) && link->setBodyAngleToCamera()) {
                link->setHookshotSight();
            }
            dComIfGp_clearPlayerStatus0(0, 0x40000);
        } else {
            dComIfGp_setPlayerStatus0(0, 0x40000);
        }
    }

    // checkNextAction() may consume the held item-button frame after the
    // function cleared mSight above. Keep the custom reticle visible for the
    // complete ready/aiming state; the launched/returning states still hide it.
    if (fixed_clawshot_aim_active(link) && link->checkHookshotWait()) {
        draw_fixed_camera_sight(link);
    }

    *static_cast<int*>(retval) = 1;
    return HOOK_SKIP_ORIGINAL;
}

HookAction replace_iron_ball_subject(ModContext*, void* args, void* retval, void*) {
    auto* link = mods::arg<daAlink_c*>(args, 0);
    if (link->checkIronBallAnime()) {
        link->setDoStatus(BUTTON_STATUS_BACK);
    }
    link->setShapeAngleToAtnActor(0);

    if (!link->checkNextAction(0) && link->itemButton() && link->mItemVar0.field_0x3018 == 2) {
        if (!update_subject_aim(link, AimItem::IronBall)) {
            link->setBodyAngleToCamera();
        }
    }

    *static_cast<int*>(retval) = 1;
    return HOOK_SKIP_ORIGINAL;
}

HookAction replace_copy_rod_subject(ModContext*, void* args, void* retval, void*) {
    auto* link = mods::arg<daAlink_c*>(args, 0);
    if (!link->checkItemActorPointer()) {
        *static_cast<int*>(retval) = 1;
        return HOOK_SKIP_ORIGINAL;
    }

    if (link->checkCopyRodReadyAnime()) {
        link->setDoStatus(BUTTON_STATUS_BACK);
    }
    link->setShapeAngleToAtnActor(0);

    if (!link->checkNextAction(0)) {
        if (!update_subject_aim(link, AimItem::CopyRod) && link->setBodyAngleToCamera()) {
            link->setCopyRodSight();
        }
    } else {
        link->mSight.offDrawFlg();
    }

    *static_cast<int*>(retval) = 1;
    return HOOK_SKIP_ORIGINAL;
}

bool player_in_supported_aim_state(dCamera_c* camera) {
    auto* link = daAlink_getAlinkActorClass();
    if (link == nullptr || camera == nullptr) {
        return false;
    }

    return player_in_supported_aim_status(camera->mPadID);
}

void after_subject_camera(ModContext*, void* args, void*, void*) {
    auto* camera = mods::arg<dCamera_c*>(args, 0);
    auto* link = daAlink_getAlinkActorClass();
    if (!use_third_person_camera_for(link) || !s_thirdPersonAimActive || camera == nullptr ||
        link == nullptr || !player_in_supported_aim_state(camera) ||
        is_hawkeye_bow(link) || camera->mCurMode != 8)
    {
        return;
    }

    // Use the same yaw/pitch as native subject aiming, without a second orbit input.
    const s16 yaw = link->getCameraAngleY();
    const s16 pitch = link->getCameraAngleX();
    cXyz center, eye;
    third_person_aim_frame(link,camera,yaw,pitch,s_thirdPersonDistance,s_thirdPersonHeight,center,eye);
    camera->mViewCache.mCenter = center;
    camera->mViewCache.mEye = eye;
    camera->mViewCache.mDirection.Val(eye - center);
    camera->mViewCache.mFovy = s_thirdPersonFovy;
    if (link->checkMagneBootsOn()) {
        // Keep the native magnetic camera's orientation/distance queries in sync.
        camera->mUpOverride.field_0x0 = center;
        camera->mUpOverride.field_0xc = eye;
        camera->mUpOverride.field_0x24 = camera->mViewCache.mDirection;
        camera->mUpOverride.field_0x18 = *link->getMagneBootsTopVec();
    }
}

void after_camera_run(ModContext*, void* args, void*, void*) {
    auto* camera = mods::arg<dCamera_c*>(args, 0);
    auto* link = daAlink_getAlinkActorClass();
    if (camera == nullptr || !use_scope_suppress_camera() || !player_in_supported_aim_state(camera) ||
        is_hawkeye_bow(link))
    {
        return;
    }

    const int zoomPercent = cinema_zoom_percent();
    if (use_cinema_camera_for(link) && zoomPercent != 100) {
        const float zoom = std::clamp(static_cast<float>(zoomPercent) / 100.0f, 0.25f, 4.0f);
        camera->mFovy = std::clamp(camera->mFovy / zoom, 10.0f, 120.0f);
    }

    const bool subjectAiming = dComIfGp_checkPlayerStatus0(camera->mPadID, 0x1040);
    if (dCamera_c::isAimActive() && fixed_camera_sight_active(link)) {
        draw_fixed_camera_sight(link);
    } else if (dCamera_c::isAimActive() &&
        (fixed_bow_aim_active(link) || custom_slingshot_sight_active(link))) {
        // Mounted Bow/Slingshot aiming bypasses replace_bow_subject, so no earlier hook
        // may have activated our sight. Draw from the current aim state after
        // the camera has updated, including the first aiming frame on Epona.
        draw_bow_trajectory_sight(link);
    } else if (s_customCinemaSightActive && subjectAiming && should_keep_cinema_bow_sight(link)) {
        draw_bow_trajectory_sight(link);
    }
}

void after_camera_next_mode(ModContext*, void* args, void* retval, void*) {
    auto* camera = mods::arg<dCamera_c*>(args, 0);
    auto* result = static_cast<s32*>(retval);
    if (camera == nullptr || result == nullptr || !use_scope_suppress_camera() ||
        !player_in_supported_aim_state(camera))
    {
        return;
    }
    if (is_hawkeye_bow(daAlink_getAlinkActorClass())) {
        return;
    }

    if (*result == 7 || *result == 8) {
        prepare_third_person_aim(daAlink_getAlinkActorClass());
        *result = 8;
    }
}

bool camera_type_supports_subject_aim(dCamera_c* camera, int type) {
    if (type < 0 || type >= camera->mCamTypeNum) {
        return false;
    }
    const auto& modes = camera->mCamTypeData[type].field_0x18[camera->mIsWolf];
    // Native nextMode first selects 7 for the Bow; our post-hook selects 8.
    // Both must exist, and mode 8 must actually dispatch subjectCamera.
    return modes[7] >= 0 && modes[8] >= 0 && camera->mCamParam.Algorythmn(modes[8]) == 4;
}

void after_camera_next_type(ModContext*, void* args, void* retval, void*) {
    auto* camera = mods::arg<dCamera_c*>(args, 0);
    auto* result = static_cast<s32*>(retval);
    if (camera == nullptr || result == nullptr || !use_scope_suppress_camera() ||
        !player_in_supported_aim_state(camera))
    {
        return;
    }
    if (is_hawkeye_bow(daAlink_getAlinkActorClass())) {
        return;
    }

    const int scopeType = camera->GetCameraTypeFromCameraName("Scope");
    if (*result == scopeType) {
        *result = camera->mMapToolType;
        return;
    }

    auto* link = daAlink_getAlinkActorClass();
    if (link == nullptr || !link->checkMagneBootsOn() ||
        link->checkAttentionLock() || link->checkEventRun()) {
        return;
    }
    const bool magneticType = *result == camera->GetCameraTypeFromCameraName("MagneRoof") ||
        *result == camera->GetCameraTypeFromCameraName("MagneWall") ||
        *result == camera->GetCameraTypeFromCameraName("MagneBoots");
    if (!magneticType) {
        return;
    }

    // Run selects the type BEFORE nextMode and rejects unsupported mode changes.
    // Leaving the magnetic chase type selected can bypass subjectCamera entirely.
    // Use a regular subject-capable type only while custom item aiming is active;
    // native nextType restores the magnetic chase camera when aiming ends.
    int aimType = camera->mMapToolType;
    if (!camera_type_supports_subject_aim(camera, aimType)) {
        aimType = camera->GetCameraTypeFromCameraName("FieldS");
    }
    if (camera_type_supports_subject_aim(camera, aimType)) {
        *result = aimType;
    }
}

void after_player_execute(ModContext*, void* args, void*, void*) {
    auto* link = mods::arg<daAlink_c*>(args, 0);
    if (link == nullptr || !use_third_person_camera_for(link) || is_hawkeye_bow(link) ||
        (!bullet_time_active_for(link) && !player_in_supported_aim_status(0)))
    {
        s_thirdPersonAimActive = false;
    }
    if (!s_customCinemaSightActive) {
        return;
    }

    if (link != nullptr && use_scope_suppress_camera() &&
        (bullet_time_active_for(link) ||
            (dCamera_c::isAimActive() && player_in_supported_aim_status(0))))
    {
        return;
    }

    if (link != nullptr) {
        link->mSight.offDrawFlg();
        link->mSight.offLockFlg();
    }
    s_customCinemaSightActive = false;
}

ModResult add_aim_hooks(ModError* error, ModResult result) {
    if (result == MOD_OK) {
        result = mods::hook_add_pre<BoomerangSubjectHook>(svc_hook, replace_boomerang_subject);
    }
    if (result == MOD_OK) {
        result = mods::hook_add_pre<HookshotSubjectHook>(svc_hook, replace_hookshot_subject);
    }
    if (result == MOD_OK) {
        result = mods::hook_add_pre<IronBallSubjectHook>(svc_hook, replace_iron_ball_subject);
    }
    if (result == MOD_OK) {
        result = mods::hook_add_pre<CopyRodSubjectHook>(svc_hook, replace_copy_rod_subject);
    }
    if (result == MOD_OK) {
        result = mods::hook_add_post<CameraNextModeHook>(svc_hook, after_camera_next_mode);
    }
    if (result == MOD_OK) {
        result = mods::hook_add_post<CameraNextTypeHook>(svc_hook, after_camera_next_type);
    }
#if DAWNLIGHT_HAS_PRIVATE_TOUCH_UI
    if (result == MOD_OK) {
        ModResult touchResult = resolve_touch_aim_symbols();
#if defined(__ANDROID__)
        result = touchResult;
#else
        if (touchResult != MOD_OK) {
            s_touchEventId = nullptr;
            s_touchEventPosition = nullptr;
            s_touchDpScale = nullptr;
            s_rmlContext = nullptr;
            s_rmlContextDimensions = nullptr;
            s_rmlSetClass = nullptr;
            s_rmlSetProperty = nullptr;
        }
#endif
    }
    if (result == MOD_OK) {
        if (s_touchEventId != nullptr) {
            result = mods::hook_add_pre<TouchSyncStateHook>(svc_hook, before_touch_sync_state);
        }
    }
    if (result == MOD_OK) {
        if (s_touchEventId != nullptr) {
            result = mods::hook_add_post<TouchSyncStateHook>(svc_hook, after_touch_sync_state);
        }
    }
    if (result == MOD_OK) {
        if (s_touchEventId != nullptr) {
            result = mods::hook_add_pre<TouchHandleDownHook>(svc_hook, before_touch_handle_down);
        }
    }
#endif
    if (result == MOD_OK) {
        result = mods::hook_add_post<PlayerExecuteHook>(svc_hook, after_player_execute);
    }
    if (result == MOD_OK) {
        result = mods::hook_add_pre<BowModelCalcHook>(svc_hook, before_bow_model_calc);
    }
    if (result == MOD_OK) {
        result = mods::hook_add_post<BowModelCalcHook>(svc_hook, after_bow_model_calc);
    }
    if (result == MOD_OK) {
        result = mods::hook_add_pre<HookshotPosHook>(svc_hook, before_hookshot_pos);
    }
    if (result == MOD_OK) {
        result = mods::hook_add_post<HookshotPosHook>(svc_hook, after_hookshot_pos);
    }
    if (result == MOD_OK) {
        result = mods::hook_add_post<BowArrowShootingHook>(svc_hook, after_bow_arrow_shooting);
    }
    if (result == MOD_OK) {
        result = mods::hook_add_post<SubjectCameraHook>(svc_hook, after_subject_camera);
    }
    if (result == MOD_OK) {
        result = mods::hook_add_post<CameraRunHook>(svc_hook, after_camera_run);
    }
    if (result != MOD_OK) {
        return mods::set_error(error, result, "failed to install Dawnlight aim hooks");
    }
    return MOD_OK;
}

}  // namespace

#include "aim_third_person.inc"

void prepare_bullet_time_bow_aim(daAlink_c* link) {
    prepare_third_person_aim(link);
    if (link == nullptr || !use_cinema_camera_for(link) || is_hawkeye_bow(link)) {
        return;
    }

    face_camera_view_yaw(link);
}

bool update_bullet_time_bow_aim(daAlink_c* link) {
    if (!should_keep_cinema_bow_sight(link)) {
        return false;
    }
    prepare_third_person_aim(link);

#if DAWNLIGHT_HAS_PRIVATE_TOUCH_UI
    if (s_touchBulletTimeMoveActive) {
        link->setBodyAngleToCamera();
        apply_bullet_time_gyro(link);
        draw_camera_center_sight(link);
        return true;
    }
#endif

    if (!aim_movement_enabled()) {
        link->setBodyAngleToCamera();
        apply_bullet_time_gyro(link);
        draw_camera_center_sight(link);
        return true;
    }

    if (use_cinema_camera_for(link)) {
        face_camera_view_yaw(link);
    } else {
        aim_with_c_stick(link);
    }
    keep_cinema_bow_sight(link);
    apply_bullet_time_gyro(link);
    return true;
}

ModResult install_aim_hooks(ModError* error) {
#if DAWNLIGHT_IOS
    if(svc_log)svc_log->warn(mod_ctx,
        "Dawnlight iOS: native touch aiming retained; private touch entries have no prepatch support");
#endif
    return add_aim_hooks(error, mods::hook_add_pre<BowSubjectHook>(svc_hook, replace_bow_subject));
}

}  // namespace dawnlight

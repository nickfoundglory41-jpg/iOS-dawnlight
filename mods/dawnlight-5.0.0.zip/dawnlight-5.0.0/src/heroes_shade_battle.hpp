#pragma once
#include "heroes_shade_trials.hpp"
#include <algorithm>
#include <array>
#include <cmath>
namespace dawnlight::shade {
// Native teaching action numbers, animation sequences and success events.
// No teaching cutscene is allowed to run in the arena.
struct Phase { int type, action, success, attack; };
inline constexpr std::array<Phase, 8> phases{{
    {0, 2, 7, 21},   // Ending Blow / downward thrust
    {1, 5, 10, 23},  // Shield Attack / shield strike
    {1, 7, 11, -1},  // reflected magic ball (native projectile)
    {2, 8, 14, 17},  // Back Slice / sidestep, roll, slash
    {3, 9, 16, 13},  // Helm Splitter
    {4, 12, 19, 12}, // Mortal Draw
    {5, 13, 21, 10}, // Jump Strike and two doubles
    {6, 19, 24, 26}, // Spin Attack (normal or Great Spin) and two doubles
}};
inline constexpr int sword = 25;
inline constexpr int back_slice = 17;
inline constexpr int helm_splitter = 13;
inline constexpr int jump_strike = 10;
// Link's base damage is counted in quarter-heart units.
inline constexpr int normal_attack_power = 4;
inline constexpr int special_attack_power = 8;
inline int attack_power(int attack) {
    return attack<0 || attack==sword ? normal_attack_power : special_attack_power;
}

// Native sequences keep their sequence number when they return to the ready
// stance. Checking only sequence 9 would strand the offensive controller.
inline bool ready_motion(int motion, int step) {
    // Ending Blow's ordinary hit reaction (31) returns to the walking stance;
    // the arena must resume attacking once that reaction/sliding has finished.
    return motion == 9 || ((motion == sword || motion == 27 || motion == 24 || motion == 31) && step >= 1);
}

struct AttackChain {
    unsigned blocks = 0;
    unsigned counters = 0;
    unsigned cycle = 0;
    int remaining = 0;
    int finisher = helm_splitter;

    void blocked_sword() {
        if (++blocks == 2) { blocks = 0; ++counters; }
    }
    void cancel() { remaining = 0; }
    void begin(unsigned phase) {
        if (counters) {
            --counters;
            remaining = 2;
            finisher = back_slice;
        } else {
            // Jumping moves are available from the first combo, independent of
            // which lesson counter currently exposes the boss to damage.
            const int skill = phases[phase].attack;
            const std::array<int, 4> finishers{
                helm_splitter, back_slice, jump_strike, skill >= 0 ? skill : back_slice};
            finisher = finishers[cycle++ % finishers.size()];
            remaining = 3;
        }
    }
    int next() {
        if (!remaining) return -1;
        return --remaining ? sword : finisher;
    }
};

// The native forward/backward airborne reactions each have a matching
// landing sequence which advances into a flat lying pose.
inline int knockdown_landing_motion(int motion) {
    return motion==18 ? 19 : motion==14 ? 15 : -1;
}

inline bool jumping_attack(int attack) {
    return attack == helm_splitter || attack == jump_strike;
}
inline bool striking_step(int attack, int step) {
    if (attack == sword) return step == 0;
    // The Back Slice sequence has a sidestep and roll before the sword cut.
    if (step!=(attack==back_slice ? 2 : 0)) return false;
    for (const auto& phase : phases) if (phase.attack == attack && attack >= 0) return true;
    return false;
}

// KN_KABUTO: shield thrust, aerial cut, then the thrust into its final stance.
// Recovery/held stance must not repeatedly damage someone touching the weapon.
inline int helm_strike(float frame) {
    if (frame>=8 && frame<19) return 0;
    if (frame>=27 && frame<68) return 1;
    if (frame>=68 && frame<=76) return 2;
    return -1;
}
// KN_DAIJUMP: first sweep at takeoff, then the downward landing blow.
// Charging, the intervening somersault and recovery do not spend either hit.
inline int jump_strike_phase(float frame) {
    if (frame>=40 && frame<50) return 0;
    if (frame>=58 && frame<=66) return 1;
    return -1;
}
struct BladePoint { float x, y, z; };
inline float blade_distance_squared(const BladePoint& a, const BladePoint& b) {
    const float x=a.x-b.x, y=a.y-b.y, z=a.z-b.z;
    return x*x+y*y+z*z;
}
struct BladeMotion {
    std::array<BladePoint,2> previous{};
    int attack = -1;
    int step = -1;
    float frame = -1;
    bool resolved = false;
    unsigned contacts = 0;
    bool sweep = false;
    int strikePhase = -1;

    void contact() {
        if (!resolved) { resolved=true; ++contacts; }
    }

    bool sample(int next_attack, int next_step, float next_frame,
                const std::array<BladePoint,2>& points) {
        const bool continuous=attack==next_attack && step==next_step && next_frame>frame;
        const bool cut_entry=attack==back_slice && next_attack==back_slice && step==1 && next_step==2;
        const float travel=std::max(blade_distance_squared(points[0],previous[0]),
                                    blade_distance_squared(points[1],previous[1]));
        sweep=continuous && travel<=300.0f*300.0f;
        if (next_attack==sword) {
            // KN_MAGIC at 1.65x moves the tip about 322 units in a single tick.
            // Trace only consecutive poses inside the native damage window;
            // never sweep windup, a skipped interval or a return pose into it.
            sweep=continuous && next_step==0 && frame>=30 && next_frame<=40 &&
                next_frame-frame<=2.0f && travel<=400.0f*400.0f;
        }
        if (jumping_attack(next_attack)) {
            const int strike=next_attack==helm_splitter ? helm_strike(next_frame) : jump_strike_phase(next_frame);
            if (strike>strikePhase) {
                // Consume previous-pose contacts before advancing the budget.
                // Only a later authored strike may rearm; a frame rewind cannot.
                if (continuous) resolved=false;
                strikePhase=strike;
            }
            // Never trace the shield attachment into the sword attachment.
            if (next_attack==helm_splitter && frame<27 && next_frame>=27) sweep=false;
        }
        attack=next_attack; step=next_step; frame=next_frame; previous=points;
        // Register the first cut pose immediately. Do not sweep the preceding
        // non-damaging roll into this strike.
        if (cut_entry && !resolved) return true;
        if (resolved || !continuous || !striking_step(attack,step)) return false;
        if (attack==helm_splitter) {
            if (step!=0 || helm_strike(frame)<0) return false;
            // The final planted thrust gets endpoint contact even as it settles;
            // its consumed budget still prevents repeated damage from the hold.
            if (frame>=75 && frame<=76) return travel<=300.0f*300.0f;
            if (!sweep) return false;
        }
        if (attack==jump_strike && jump_strike_phase(frame)<0) return false;
        if (attack==sword) return frame>=30 && frame<=40; // native ordinary swing
        // Special animation lengths/windups differ. Use the posed blade's
        // movement, not an invented common percentage of the animation. The
        // native collision volumes decide whether that blade actually hits.
        // Stationary poses and discontinuities (e.g. a warp) cannot hit.
        return travel>=1.0f && travel<=300.0f*300.0f;
    }
};

struct GroundPoint { float x, z; };
inline GroundPoint jump_landing_target(int attack, GroundPoint origin, GroundPoint target) {
    const float dx=target.x-origin.x, dz=target.z-origin.z;
    const float distance=std::sqrt(dx*dx+dz*dz);
    if (distance<0.001f) return target;
    // Helm Splitter turns around during the somersault: land beyond Link so
    // its backwards-facing cut points at him. Jump Strike stays in front.
    const float offset=attack==helm_splitter ? 140.0f : -std::min(110.0f,distance);
    return {target.x+dx/distance*offset,target.z+dz/distance*offset};
}
inline GroundPoint back_slice_offset(float start_angle, float start_radius, int step, float progress) {
    constexpr float pi = 3.14159265358979323846f;
    progress = std::clamp(progress, 0.0f, 1.0f);
    const float fraction = step == 0 ? progress / 3.0f : (1.0f + 2.0f * progress) / 3.0f;
    const float radius = step == 0 ? start_radius + (150.0f-start_radius)*progress : 150.0f;
    const float angle = start_angle + pi * fraction;
    return {std::sin(angle)*radius, std::cos(angle)*radius};
}
// Drive normal actor movement rather than changing positions directly; native
// wall/floor and actor collision still constrain the resulting displacement.
inline GroundPoint approach_velocity(float dx, float dz, float max_speed, float stop_distance) {
    const float distance = std::sqrt(dx*dx + dz*dz);
    if (distance <= stop_distance || distance < 0.001f) return {0,0};
    const float speed = std::min(max_speed, distance-stop_distance);
    return {dx/distance*speed, dz/distance*speed};
}
struct Battle {
    using Random = float (*)(float);
    std::array<unsigned,phases.size()> phase_order{0,1,2,3,4,5,6,7};
    std::array<Trial,4> trial_order{Trial::Shield,Trial::Fire,Trial::Eyes,Trial::Wind};
    unsigned phase_cursor = 0;
    unsigned phase = 0;
    unsigned defeated_doubles = 0;
    int health = starting_health;
    Trial trial = Trial::None;
    unsigned trials_started = 0;
    int remaining = 600;
    int recovery = 0;
    bool advance = false;
    bool dying = false;

    // Native cM_rndF supplies [0, count); clamp a rounded upper endpoint.
    static unsigned draw(Random random, unsigned count) {
        return std::min(static_cast<unsigned>(random(static_cast<float>(count))),count-1);
    }
    template<class T, std::size_t N>
    static void shuffle(std::array<T,N>& order, Random random) {
        for (unsigned count=static_cast<unsigned>(N); count>1; --count)
            std::swap(order[count-1],order[draw(random,count)]);
    }
    void begin(Random random) {
        *this={};
        shuffle(phase_order,random);
        shuffle(trial_order,random);
        // Wind relies on the persistent lava rim created by the fire trial.
        // Swapping an inverted pair preserves all 12 valid shuffled orders.
        const auto fire=std::find(trial_order.begin(),trial_order.end(),Trial::Fire);
        const auto wind=std::find(trial_order.begin(),trial_order.end(),Trial::Wind);
        if (wind<fire) std::iter_swap(fire,wind);
        phase=phase_order.front();
    }
    Trial next_trial() const {
        return trials_started<trial_order.size() ? trial_order[trials_started] : Trial::None;
    }
    Trial audio_trial() const {
        return trial!=Trial::None ? trial : next_trial();
    }
    bool phase_allowed(unsigned candidate) const {
        // The last hit must not use the two clone/group-warp lessons.
        return health!=1 || candidate<6;
    }
    void event(int event) {
        if (recovery || dying || trial!=Trial::None) return;
        if (event == phases[phase].success) {
            --health;
            recovery = 45;
            advance = true;
        }
    }
    bool tick(Random random) {
        if (dying || trial!=Trial::None) return false;
        if (recovery && --recovery) return false;
        if (health == 0) { dying = true; return true; }
        if (next_trial()!=Trial::None && health==starting_health-2*static_cast<int>(trials_started+1)) {
            trial=next_trial();
            ++trials_started;
            return true;
        }
        if (advance || --remaining == 0) {
            const auto previous=phase;
            do {
                if (++phase_cursor==phase_order.size()) {
                    shuffle(phase_order,random);
                    // Compare the first playable phase, including at 1 HP
                    // when the shuffled bag can begin with excluded lessons.
                    auto first=std::find_if(phase_order.begin(),phase_order.end(),
                        [this](unsigned candidate){return phase_allowed(candidate);});
                    if (*first==previous) {
                        std::array<unsigned,phases.size()> alternatives{};
                        unsigned count=0;
                        for(unsigned i=0;i<phase_order.size();++i)
                            if(phase_allowed(phase_order[i]) && phase_order[i]!=previous)
                                alternatives[count++]=i;
                        std::iter_swap(first,phase_order.begin()+alternatives[draw(random,count)]);
                    }
                    phase_cursor=0;
                }
                phase=phase_order[phase_cursor];
            } while (!phase_allowed(phase));
            defeated_doubles = 0;
            remaining = 600;
            advance = false;
            return true;
        }
        return false;
    }
};
}

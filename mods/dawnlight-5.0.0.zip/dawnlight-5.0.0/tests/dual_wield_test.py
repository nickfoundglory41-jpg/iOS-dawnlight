"""Exercise real Dual Wield code with a small native-API fixture; no game files."""
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
source = (root / "src/dual_wield.cpp").read_text()


def function(name, result="void"):
    start = source.index(f"{result} {name}(")
    return source[start:source.index("\n}\n", start) + 3]


animation_api = r'''
#pragma once
#include <cstdint>
using u16=std::uint16_t;using s16=std::int16_t;
struct J3DTransformInfo {
    struct {float x=1,y=1,z=1;} mScale;
    struct {s16 x=0,y=0,z=0;} mRotation;
    struct {float x=0,y=0,z=0;} mTranslate;
};
struct J3DAnmTransform {
    int field_0x1e=35,kind=8;float frame=0;
    virtual ~J3DAnmTransform()=default;
    int getKind() const{return kind;}
    float getFrame() const{return frame;}
    virtual void getTransform(u16,J3DTransformInfo*) const=0;
};
struct J3DAnmTransformKey : J3DAnmTransform {
    bool armRig=false;
    void calcTransform(float t,u16 joint,J3DTransformInfo* out) const {
        if(armRig && joint>=11 && joint<=14) {
            *out={};
            // Native Link proportions; animated two-handed rotations deliberately
            // differ from bind. Full charge must not retain their axial twist.
            if(joint==11)out->mTranslate={13.798f,0,-2};
            if(joint==12)out->mTranslate={15.692f,-1.017f,0};
            if(joint==13)out->mTranslate={29,0,0};
            if(joint==14)out->mTranslate={26.5f,0,0};
            out->mRotation={s16(-8000+t*80),s16(6000+t*50),s16(14000+t*20)};
            return;
        }
        *out={};out->mTranslate={float(joint),t,float(100+joint)};
        out->mRotation={s16(joint*30),s16(joint*20),s16(joint*10)};
        if(joint==0) out->mRotation={s16(t*80),s16(t*100),s16(t*180)};
    }
    void getTransform(u16 joint,J3DTransformInfo* out) const override {calcTransform(frame,joint,out);}
};
struct mDoExt_AnmRatioPack {
    J3DAnmTransform* value=nullptr;
    auto getAnmTransform(){return value;}
    void setAnmTransform(J3DAnmTransform* p){value=p;}
};
'''

fixture = r'''
#include "dual_wield_animation.hpp"
#include "dual_wield_math.hpp"
#include "dual_wield_sword.hpp"
#include <array>
#include <cassert>
#include <optional>
using namespace dawnlight;
using dual::Pose;using dual::Vec;
struct ModContext {};
enum HookAction {HOOK_CONTINUE};
constexpr int dItemNo_NONE_e=0xff;
enum {dItemNo_BOOMERANG_e=0x40,dItemNo_BOW_e=0x43,dItemNo_HOOKSHOT_e=0x44,
 dItemNo_COPY_ROD_e=0x46,dItemNo_W_HOOKSHOT_e=0x47,dItemNo_KANTERA_e=0x48,
 dItemNo_PACHINKO_e=0x4b,dItemNo_COPY_ROD_2_e=0x4c,dItemNo_KANTERA2_e=0xf8,
 dItemNo_BOMB_ARROW_e=0x59,dItemNo_HAWK_ARROW_e=0x5a};
struct Args {void* link;void* model=nullptr;};
namespace mods {template<class T>T arg(void* p,int i){auto* a=static_cast<Args*>(p);return static_cast<T>(i?a->model:a->link);}}
struct RigJoint {J3DTransformInfo transform;auto& getTransformInfo(){return transform;}};
struct RigData {
    std::array<RigJoint,35> joints;
    RigData(){joints[11].transform.mRotation={-16384,16384,0};joints[12].transform.mRotation={16384,0,0};}
    auto* getJointNodePointer(int i){return &joints[i];}
};
struct J3DModel {RigData data;auto* getModelData(){return &data;}dual::Pose base;std::array<dual::Pose,35> joints;auto& getBaseTRMtx(){return base;}auto getAnmMtx(int i){return joints[i];}};
struct cXyz {float x=0,y=0,z=0;void set(float a,float b,float c){x=a;y=b;z=c;}};
struct Morph {
    int calls=0;bool valid=true;
    std::array<J3DTransformInfo,35> transforms;
    std::array<dual::Quat,35> quaternions;
    void initOldFrameMorf(int,int,int){++calls;}
    bool getOldFrameFlg(){return valid;}
    auto getOldFrameTransInfo(int i){return &transforms[i];}
    auto getOldFrameQuaternion(int i){return &quaternions[i];}
};
struct daPy_py_c {enum {CUT_TYPE_FINISH_LEFT,CUT_TYPE_FINISH_RIGHT,CUT_TYPE_FINISH_VERTICAL,CUT_TYPE_FINISH_STAB};};
struct daAlink_c {
    enum {PROC_CUT_NORMAL=1,PROC_CUT_FINISH=2,PROC_WAIT=3,PROC_GUARD_ATTACK=4,PROC_SWORD_UNEQUIP_SP=5,
        PROC_CUT_FINISH_JUMP_UP,PROC_CUT_FINISH_JUMP_UP_LAND,PROC_CUT_REVERSE,
        PROC_CUT_JUMP,PROC_CUT_JUMP_LAND,PROC_CUT_TURN,PROC_CUT_TURN_CHARGE,PROC_CUT_TURN_MOVE,
        PROC_CUT_DOWN,PROC_CUT_DOWN_LAND,PROC_CUT_HEAD,PROC_CUT_HEAD_LAND,
        PROC_CUT_LARGE_JUMP_CHARGE,PROC_CUT_LARGE_JUMP,PROC_CUT_LARGE_JUMP_LAND,
        PROC_LARGE_DAMAGE,PROC_LARGE_DAMAGE_WALL,PROC_LARGE_DAMAGE_UP,PROC_LAND_DAMAGE};
    int mProcID=PROC_WAIT,cut=0,mEquipItem=0x103;
    bool event=false,guard=false,human=true,equipping=false,horse=false;
    bool upperCut=false,upperCutCharge=false;
    int field_0x3198=0;
    struct {int field_0x300c=0;} mProcVar2;
    Morph morph;Morph* field_0x2060=&morph;
    J3DModel model;J3DModel* mpLinkModel=&model;
    std::array<mDoExt_AnmRatioPack,3> mNowAnmPackUnder,mNowAnmPackUpper;
    struct Frame {float frame=10,rate=1;float getFrame() const{return frame;}float getRate() const{return rate;}float getStart() const{return 0;}float getEnd() const{return 22;}};
    std::array<Frame,3> mUnderFrameCtrl,mUpperFrameCtrl;
    float field_0x3478=6,field_0x347c=14;
    cXyz field_0x3498,mSwordTopPos,field_0x3720,field_0x34a4,field_0x34b0,field_0x34bc;
    int getCutType(){return cut;}
    bool checkEventRun(){return event;}
    bool checkPlayerGuardAndAttack(){return guard;}
    bool checkHorseRide(){return horse;}
    bool checkSwordEquipAnime(){return equipping;}
    bool checkCutDashAnime(){return upperCut;}
    bool checkCutDashChargeAnime(){return upperCutCharge;}
    J3DModel* mSwordModel=nullptr;int swordShown=0,swordHidden=0;
    J3DModel* mShieldModel=nullptr;unsigned mRightItemJntNo=15;int mShieldChangeWaitTimer=0;
    bool checkStatusWindowDraw(){return false;}
    void offSwordModel(){++swordHidden;}
};
struct State {
    SecondSword swordType=SecondSword::Ordon;
    daAlink_c* owner=nullptr;
    bool enabled=false,active=false,mirror=false,seedBlade=false,forcedBlade=false;
    float guard=0,draw=0,sheathTilt=0,charge=0;Pose chargeMount;DualChargeArmPose chargeArm;unsigned tick=0,poseTick=~0u;
    dual::Alternation attacks;
    DualGuardBodyPose guardBody;bool haveGuardBody=false;
    dual::StowMotion stow;Pose rightSword,hipSword,nativeShield;unsigned shieldTick=~0u;J3DModel* sword=nullptr;J3DModel* sheath=nullptr;
} s;
struct Borrow {mDoExt_AnmRatioPack* pack=nullptr;J3DAnmTransform* original=nullptr;std::optional<DualWieldAnimation> wrapper;};
std::array<Borrow,6> s_borrow;bool s_calculating=false,setting=true;
bool dual_wield_equipped(){return setting;}
daAlink_c* glidingOwner=nullptr;
bool glide_active_for(daAlink_c* link){return link==glidingOwner;}
bool human(daAlink_c* l){return l->human;}
bool active(daAlink_c* l){return s.owner==l && s.active;}
bool equipment_visible(daAlink_c* l){return s.owner==l && s.enabled;} // material/model gating tested below
Pose pose(Pose p){return p;}
void put(J3DModel* model,int joint,Pose p){model->joints[joint]=p;}
void put(J3DModel* model,Pose p){model->base=p;}
void matrix(Pose value,Pose& destination){destination=value;}
void show_guard_blade(daAlink_c* link){++link->swordShown;}
'''

fixture += "\n".join(function(name, result) for name, result in [
    ("local", "Pose"), ("status_item_matrices", "void"), ("hand_mount", "Pose"), ("sword_at_hand", "Pose"), ("solve_arm", "void"), ("detach", "void"), ("ordinary", "bool"), ("sword_attack", "bool"), ("jump_charge", "bool"), ("knocked_down", "bool"), ("sword_guard_equipment", "bool"), ("item_guard_equipment", "bool"), ("start_stow", "void"), ("start_draw", "void"), ("after_equip", "void"), ("update_stow", "void"), ("after_matrix", "void"),
    ("after_cut", "void"), ("before_guard_attack", "HookAction"),
    ("guard_thrust", "float"), ("before_model_calc", "HookAction"),
    ("after_model_calc", "void"), ("after_sword_pos", "void"),
    ("after_shield_draw", "void"), ("after_arms", "void"), ("after_items", "void"), ("before_collision", "HookAction"),
])
fixture += r'''
int main() {
    J3DAnmTransformKey original;original.frame=12.5f;
    DualWieldAnimation mirrored(original);
    for(int joint=0;joint<35;++joint) {
        const bool left=joint>=6 && joint<=9,right=joint>=11 && joint<=14;
        const bool reflect=left || right || (joint>=1 && joint<=4);
        J3DTransformInfo a,b;mirrored.getTransform(joint,&a);
        original.getTransform(left?joint+5:right?joint-5:joint,&b);
        assert(a.mTranslate.x==b.mTranslate.x && a.mTranslate.y==12.5f);
        assert(a.mTranslate.z==(reflect?-b.mTranslate.z:b.mTranslate.z));
        assert(a.mRotation.x==(reflect?-b.mRotation.x:b.mRotation.x));
        assert(a.mRotation.y==(reflect?-b.mRotation.y:b.mRotation.y));
        assert(a.mRotation.z==b.mRotation.z);
        assert(a.mScale.x==1);
    }
    assert(original.frame==12.5f); // no shared BCK/frame writes

    // Link's shoulder bind is at the Euler pitch singularity. Quaternion
    // conversion must preserve it, including during partial charge blending.
    for(float pitch:{-1.57079632679f,1.57079632679f})
    for(float roll:{-1.57079632679f,0.f,.8f}) for(float yaw:{0.f,.5f}) {
        const auto q=dual::from_euler({roll,pitch,yaw});
        J3DTransformInfo t;set_joint_rotation(t,q);
        for(Vec axis:{Vec{1,0,0},Vec{0,1,0},Vec{0,0,1}})
            assert(dual::length(dual::rotate(joint_rotation(t),axis)-dual::rotate(q,axis))<.001f);
    }
    DualChargeArmPose bind{};bind[0].mRotation={-16384,16384,0};bind[1].mRotation={16384,0,0};
    pose_jump_charge_arm(bind);
    for(float weight:{0.f,.25f,.5f,.75f,1.f}) {
        DualWieldAnimation charged(original,false,nullptr,0,&bind,weight);
        for(int joint=11;joint<=14;++joint) {
            J3DTransformInfo native,actual;original.getTransform(joint,&native);charged.getTransform(joint,&actual);
            const auto expected=dual::blend(joint_rotation(native),joint_rotation(bind[joint-11]),weight);
            for(Vec axis:{Vec{1,0,0},Vec{0,1,0},Vec{0,0,1}})
                assert(dual::length(dual::rotate(joint_rotation(actual),axis)-dual::rotate(expected,axis))<.001f);
        }
    }

    daAlink_c link,other;s.owner=&link;Args args{&link,link.mpLinkModel};
    link.model.joints[9].p={-20,80,40};link.model.joints[14].p={20,80,40};
    after_matrix(nullptr,&args,nullptr,nullptr);assert(s.active && !s.mirror);
    const float draw=s.draw;
    after_matrix(nullptr,&args,nullptr,nullptr);assert(s.draw==draw); // one advance per tick
    link.mProcID=daAlink_c::PROC_CUT_NORMAL;int success=1,failed=0;
    after_cut(nullptr,&args,&success,nullptr);assert(!s.attacks.right);
    after_cut(nullptr,&args,&failed,nullptr);assert(!s.attacks.right);
    after_cut(nullptr,&args,&success,nullptr);assert(s.attacks.right);
    ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);assert(s.mirror);
    for(auto& p:link.mNowAnmPackUnder)p.value=&original;
    for(auto& p:link.mNowAnmPackUpper)p.value=&original;
    before_model_calc(nullptr,&args,nullptr,nullptr);assert(s_calculating);
    for(auto& p:link.mNowAnmPackUnder)assert(p.value!=&original);
    // Calculating an accessory must not detach body animation packs prematurely.
    J3DModel accessory;Args itemArgs{&link,&accessory};
    after_model_calc(nullptr,&itemArgs,nullptr,nullptr);assert(s_calculating);
    after_model_calc(nullptr,&args,nullptr,nullptr);assert(!s_calculating);
    for(auto& p:link.mNowAnmPackUnder)assert(p.value==&original);
    for(auto& p:link.mNowAnmPackUpper)assert(p.value==&original);

    // Right contact uses the 100-unit Ordon blade. First sample must not sweep
    // across from the preceding left-hand strike; later samples stay untouched.
    s.seedBlade=true;after_sword_pos(nullptr,&args,nullptr,nullptr);
    assert(link.mSwordTopPos.x==120 && link.mSwordTopPos.y==80);
    assert(link.field_0x34b0.x==120 && link.field_0x34bc.x==20 && !s.seedBlade);
    link.field_0x34b0.x=99;after_sword_pos(nullptr,&args,nullptr,nullptr);
    assert(link.field_0x34b0.x==99);
    s.swordType=SecondSword::Master;s.seedBlade=true;
    after_sword_pos(nullptr,&args,nullptr,nullptr);
    assert(link.mSwordTopPos.x==140 && link.field_0x34b0.x==140);
    s.swordType=SecondSword::Ordon;
    bool shield=true;after_shield_draw(nullptr,&args,&shield,nullptr);assert(!shield);
    Args otherArgs{&other};shield=true;after_shield_draw(nullptr,&otherArgs,&shield,nullptr);assert(shield);

    // Unsupported mixed animation rigs must not use right-hand hit positions.
    original.field_0x1e=30;before_model_calc(nullptr,&args,nullptr,nullptr);
    assert(!s_calculating && !s.mirror);original.field_0x1e=35;
    ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);assert(s.mirror);
    link.event=true;++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);assert(!s.active && !s.mirror);
    shield=true;after_shield_draw(nullptr,&args,&shield,nullptr);assert(!shield);
    link.event=false;setting=false;++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
    assert(!s.enabled && !s.active && !s.attacks.right);
    shield=true;after_shield_draw(nullptr,&args,&shield,nullptr);assert(shield);
    setting=true;++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
    after_cut(nullptr,&args,&success,nullptr);assert(!s.attacks.right);
    // Event/wolf boundaries never modify another rig.
    link.human=false;++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);assert(!s.active);

    // Root/pelvis/legs must remain one native motion. Chest orientation stays
    // stable despite the root rotation; only a 3-unit forward translation is added.
    link.human=true;link.mProcID=daAlink_c::PROC_WAIT;
    ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
    link.morph.transforms[0].mTranslate.y=102;
    link.morph.quaternions[0]=dual::between({1,0,0},{0,1,0});
    before_guard_attack(nullptr,&args,nullptr,nullptr);assert(s.haveGuardBody);
    assert(std::abs(s.guardBody[0].mRotation.z-16384)<=1);
    link.mProcID=daAlink_c::PROC_GUARD_ATTACK;
    ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
    for(float frame:{2.0f,10.0f,18.0f}) {
        link.mUnderFrameCtrl[0].frame=frame;original.frame=frame;
        before_model_calc(nullptr,&args,nullptr,nullptr);assert(s_calculating);
        auto* anm=link.mNowAnmPackUnder[0].value;
        J3DTransformInfo root,spine,leg;
        anm->getTransform(0,&root);anm->getTransform(1,&spine);anm->getTransform(17,&leg);
        for(int joint=0;joint<=26;++joint) {
            if(joint>0 && joint<16)continue;
            J3DTransformInfo actual,native;
            anm->getTransform(joint,&actual);original.getTransform(joint,&native);
            assert(actual.mTranslate.x==native.mTranslate.x && actual.mTranslate.y==native.mTranslate.y && actual.mTranslate.z==native.mTranslate.z);
            assert(actual.mRotation.x==native.mRotation.x && actual.mRotation.y==native.mRotation.y && actual.mRotation.z==native.mRotation.z);
        }
        auto rotation=[](const J3DTransformInfo& t) {
            constexpr float radians=3.14159265358979323846f/32768;
            return dual::from_euler({t.mRotation.x*radians,t.mRotation.y*radians,t.mRotation.z*radians});
        };
        const auto world=dual::multiply(rotation(root),rotation(spine));
        assert(dual::length(dual::rotate(world,{1,0,0})-Vec{0,1,0})<.001f);
        assert(dual::length(dual::rotate(world,{0,0,1})-Vec{0,0,1})<.001f);
        const auto shift=dual::rotate(rotation(root),{spine.mTranslate.x,spine.mTranslate.y,spine.mTranslate.z});
        assert(dual::length(shift-Vec{0,0,frame==10 ? 3.0f : 0.0f})<.001f);
        assert(leg.mTranslate.y==frame && leg.mRotation.x==17*30);
        after_model_calc(nullptr,&args,nullptr,nullptr);
        assert(link.mNowAnmPackUnder[0].value==&original);
    }
    link.mProcID=daAlink_c::PROC_WAIT;
    ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);assert(!s.haveGuardBody);

    // A morph can have stale Euler angles and a different blended quaternion.
    // Both the hand solver and rendered primary item must use the latter.
    for(int sample=0;sample<=20;++sample) {
        const float t=sample/20.0f;
        auto& grip=link.morph.transforms[10];
        grip.mRotation={0,16384,0}; // deliberately differs from the rendered rotation
        grip.mTranslate={9.664279f,2.136274f,3.018636f};
        link.morph.quaternions[10]=dual::blend(dual::Quat{-.579250f,-.405549f,.405549f,.579250f},
                                             dual::Quat{0,0,0,1},t);
        const Pose mount=hand_mount(&link,false);
        assert(dual::length(dual::rotate(mount.q,{1,0,0})-
                           dual::rotate(link.morph.quaternions[10],{1,0,0}))<.001f);
        link.model.joints[7]={{},{18,130,-10}};
        link.model.joints[8]={{},{32,105,0}};
        link.model.joints[9]={{},{24,93,22}};
        link.model.joints[10]={{},{-30,100,0}}; // native item matrix that would fold the blade
        const Pose blade=dual::cross_guard_blade(false,t);
        solve_arm(&link,false,blade,1);
        const Pose rendered=link.model.joints[10];
        const Pose attached=dual::compose(link.model.joints[9],mount);
        assert(dual::length(rendered.p-attached.p)<.001f);
        for(Vec axis:{Vec{1,0,0},Vec{0,1,0},Vec{0,0,1}})
            assert(dual::length(dual::rotate(rendered.q,axis)-dual::rotate(blade.q,axis))<.001f);
    }

    // Begin while the sword is still equipped; keep the offhand override
    // through the native inventory switch and the late shield-back frames.
    link.equipping=true;link.mEquipItem=0x103;
    s.stow={};s.stow.active=true;
    link.mUpperFrameCtrl[2].frame=5;
    ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
    assert(s.stow.active && s.stow.progress>0 && s.draw==1);
    link.mEquipItem=dItemNo_NONE_e;link.mUpperFrameCtrl[2].frame=11;
    ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
    assert(s.stow.active && s.draw==1);
    link.mUpperFrameCtrl[2].frame=18;
    ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
    assert(s.stow.active && s.draw==0);
    link.equipping=false;
    ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
    assert(!s.stow.active && s.stow.release==1);
    for(int i=0;i<7;++i){++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);}
    assert(s.stow.release==0);
    // Draw starts before the inventory swap, using the reversed equip clock.
    s.draw=0;link.equipping=true;link.mEquipItem=dItemNo_NONE_e;
    link.mUpperFrameCtrl[2].rate=-1;link.mUpperFrameCtrl[2].frame=22;
    after_equip(nullptr,&args,nullptr,nullptr);
    assert(s.stow.active && s.stow.drawing && s.stow.duration==22);
    link.mUpperFrameCtrl[2].frame=18;
    ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
    assert(s.draw==0); // empty hand approaches; sword remains in its sheath
    const float tilt=s.sheathTilt;assert(tilt>0);
    after_matrix(nullptr,&args,nullptr,nullptr);assert(s.sheathTilt==tilt);
    link.mUpperFrameCtrl[2].frame=14;
    ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);assert(s.draw==1);
    link.mEquipItem=0x103;link.mUpperFrameCtrl[2].frame=5;
    ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
    assert(s.stow.active && s.stow.drawing && s.draw==1);
    link.equipping=false;
    ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
    assert(!s.stow.active && s.stow.release==1);
    // Raising/lowering guard while holstered uses both halves of the same
    // route even when there is no native equip animation controller.
    s.stow={};s.draw=0;link.mEquipItem=dItemNo_NONE_e;link.guard=true;
    for(int i=0;i<21;++i){++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);}
    assert(s.draw==1 && !s.stow.active);
    for(int i=0;i<6;++i){++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);}
    link.guard=false;++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
    assert(s.stow.active && !s.stow.drawing && !s.stow.nativeClock);
    for(int i=0;i<25;++i){++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);}
    assert(s.draw==0 && !s.stow.active);
    // Hold block throughout the complete aerial technique, including charge
    // and landing. Neither lingering guard IK nor a hip draw may own its arms.
    link.guard=true;link.mEquipItem=0x103;
    for(int proc:{daAlink_c::PROC_CUT_JUMP,daAlink_c::PROC_CUT_JUMP_LAND,
                  daAlink_c::PROC_CUT_HEAD,daAlink_c::PROC_CUT_HEAD_LAND,
                  daAlink_c::PROC_CUT_LARGE_JUMP_CHARGE,daAlink_c::PROC_CUT_LARGE_JUMP,
                  daAlink_c::PROC_CUT_LARGE_JUMP_LAND,daAlink_c::PROC_CUT_FINISH_JUMP_UP,
                  daAlink_c::PROC_CUT_FINISH_JUMP_UP_LAND}) {
        link.mProcID=proc;s.guard=1;s.haveGuardBody=true;
        s.stow.active=true;s.stow.drawing=true;s.stow.release=1;s.draw=0;
        ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
        assert(s.guard==0 && !s.stow.active && s.stow.release==0 && s.draw>0);
        assert(!s.haveGuardBody && !s.mirror);
        before_model_calc(nullptr,&args,nullptr,nullptr);assert(s_calculating==jump_charge(&link));
        after_model_calc(nullptr,&args,nullptr,nullptr);
        ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);assert(s.guard==0);
    }
    // A held/manual guard signal must not pose the arms during knockback,
    // floor recovery or getting up, including a hit during a hip draw/stow.
    for(int proc:{daAlink_c::PROC_LARGE_DAMAGE,daAlink_c::PROC_LARGE_DAMAGE_WALL,
                  daAlink_c::PROC_LARGE_DAMAGE_UP,daAlink_c::PROC_LAND_DAMAGE}) {
        for(int item:{0x103,dItemNo_NONE_e}) for(bool drawing:{false,true}) {
            link.mProcID=proc;link.mEquipItem=item;link.guard=true;
            s.guard=1;s.draw=1;s.stow.active=true;s.stow.drawing=drawing;s.stow.release=1;
            ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
            assert(s.guard==0 && !s.stow.active && s.stow.release==0);
            assert(!s.haveGuardBody && !s.mirror);
            // Pressing block after reaching the floor must not start a draw,
            // even after the previous blend has had plenty of time to settle.
            s.draw=0;link.guard=false;
            ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
            link.guard=true;
            for(int frame=0;frame<30;++frame) {
                ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
                assert(s.guard==0 && !s.stow.active && s.stow.release==0);
            }
            before_model_calc(nullptr,&args,nullptr,nullptr);assert(!s_calculating);
        }
    }
    link.mEquipItem=0x103;
    // After recovery, held block blends back in as usual.

    link.mProcID=daAlink_c::PROC_WAIT;
    ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);assert(s.guard>0 && s.guard<1);
    for(int i=0;i<5;++i){++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);}
    assert(s.guard==1);
    link.mProcID=daAlink_c::PROC_GUARD_ATTACK;
    ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);assert(s.guard==1);
    // An attack interruption immediately returns ownership to combat.
    s.stow.active=true;s.sheathTilt=1;link.mProcID=daAlink_c::PROC_CUT_NORMAL;
    ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
    assert(!s.stow.active && s.stow.release==0);
    assert(s.sheathTilt>0 && s.sheathTilt<1); // return from the last pose, no snap
    for(int i=0;i<6;++i){++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);}
    assert(s.sheathTilt==0);
    // With another item, only the right arm/Ordon sword enters guard. The left
    // clavicle, arm, hand and item joint must remain byte-for-byte equivalent.
    J3DModel offhand,scabbard,primary;s.sword=&offhand;s.sheath=&scabbard;link.mSwordModel=&primary;
    link.mProcID=daAlink_c::PROC_WAIT;
    for(int joint=0;joint<35;++joint)link.model.joints[joint]={{},{float(joint),100.f,0}};
    link.model.data.joints[0].transform.mTranslate.y=100;
    link.model.joints[12]={{},{-18,130,-10}};
    link.model.joints[13]={{},{-32,105,0}};
    link.model.joints[14]={{},{-24,93,22}};
    const auto nativeJoints=link.model.joints;

    const auto samePose=[](Pose a,Pose b) {
        assert(dual::length(a.p-b.p)<.003f);
        for(Vec axis:{Vec{1,0,0},Vec{0,1,0},Vec{0,0,1}})
            assert(dual::length(dual::rotate(a.q,axis)-dual::rotate(b.q,axis))<.003f);
    };
    {
        // Crouch can start on the first guarded frame. The targets must follow
        // the animated root without caching a preceding standing guard pose.
        const auto saved=s;
        daAlink_c crouch;Args crouchArgs{&crouch,crouch.mpLinkModel};
        J3DModel second,mainSword;crouch.mSwordModel=&mainSword;
        crouch.guard=true;crouch.model.data.joints[0].transform.mTranslate.y=103;
        auto standing=nativeJoints;standing[0].p={0,103,0};
        standing[7].p={18,130,-10};standing[8].p={32,105,0};standing[9].p={24,93,22};
        const auto evaluate=[&](Pose base,float drop) {
            crouch.model.base=base;
            for(int j=0;j<35;++j) {
                auto joint=standing[j];joint.p.y-=drop;
                crouch.model.joints[j]=dual::compose(base,joint);
            }
        };
        s={};s.owner=&crouch;s.sword=&second;s.draw=1;s.guard=1;
        evaluate({},0);
        ++s.tick;after_matrix(nullptr,&crouchArgs,nullptr,nullptr);
        after_arms(nullptr,&crouchArgs,nullptr,nullptr);
        const auto leftStanding=crouch.model.joints[10],rightStanding=s.rightSword;
        // Include lowering/rising, translated world origins and tilted actors.
        for(const Pose base:{Pose{},Pose{dual::from_euler({.2f,1.3f,-.1f}),{200,800,-300}}}) {
            for(float drop:{60.f,35.f,10.f,0.f,10.f,35.f,60.f,0.f}) {
                s={};s.owner=&crouch;s.sword=&second;s.draw=1;s.guard=1;
                evaluate(base,drop);
                ++s.tick;after_matrix(nullptr,&crouchArgs,nullptr,nullptr);
                after_arms(nullptr,&crouchArgs,nullptr,nullptr);
                auto left=leftStanding,right=rightStanding;
                left.p.y-=drop;right.p.y-=drop;
                samePose(crouch.model.joints[10],dual::compose(base,left));
                samePose(s.rightSword,dual::compose(base,right));
            }
        }
        // Lazy Tweaks uses an upper-body running cut while PROC_WAIT and
        // held block remain active. Charge and attack must release all IK
        // immediately, including an interrupted sword draw/stow blend.
        for(bool charge:{false,true}) {
            crouch.upperCut=!charge;crouch.upperCutCharge=charge;
            s.guard=1;s.stow.active=true;s.stow.release=1;s.charge=1;
            for(int frame=0;frame<4;++frame) {
                evaluate({},60);
                crouch.model.joints[9]={{},{float(frame*12),65,25}};
                crouch.model.joints[10]={dual::from_euler({0,float(frame),.3f}),{float(frame*12+9),67,28}};
                const auto native=crouch.model.joints;
                ++s.tick;after_matrix(nullptr,&crouchArgs,nullptr,nullptr);
                assert(s.guard==0&&!s.stow.active&&s.stow.release==0&&s.charge==0&&!s.mirror);
                after_arms(nullptr,&crouchArgs,nullptr,nullptr);
                // Native setItemMatrix attaches the primary mesh to joint 10.
                mainSword.base=crouch.model.joints[10];
                after_items(nullptr,&crouchArgs,nullptr,nullptr);
                for(int j=0;j<35;++j)samePose(crouch.model.joints[j],native[j]);
                samePose(mainSword.base,native[10]);
                samePose(second.base,dual::secondary_sword_model_pose(sword_at_hand(&crouch,true)));
            }
        }
        crouch.upperCut=crouch.upperCutCharge=false;
        for(int frame=0;frame<5;++frame) {
            evaluate({},60);
            ++s.tick;after_matrix(nullptr,&crouchArgs,nullptr,nullptr);
            after_arms(nullptr,&crouchArgs,nullptr,nullptr);
        }
        assert(s.guard==1);
        auto left=leftStanding,right=rightStanding;left.p.y-=60;right.p.y-=60;
        samePose(crouch.model.joints[10],left);samePose(s.rightSword,right);
        s=saved;
    }
    // ANM_FINISH spins the main sword's item track. Hold all other inputs
    // fixed and rotate that track through full turns: the offhand wrist and
    // sword must stay identical during insertion, empty-hand rest and release.
    link.guard=false;s.guard=0;s.charge=0;s.stow={};s.draw=1;
    link.mProcID=daAlink_c::PROC_SWORD_UNEQUIP_SP;link.field_0x3198=0;
    link.morph.quaternions[10]=dual::from_euler({-.8f,.5f,.7f});
    link.morph.transforms[10].mTranslate={9.66f,2.14f,3.02f};
    s.rightSword=sword_at_hand(&link,true);
    const Pose gripBefore=hand_mount(&link,true);
    start_stow(&link,true);
    assert(s.stow.active&&s.stow.special);samePose(s.stow.mount,gripBefore);
    for(float progress:{.1f,.5f,1.f}) {
        Pose wrist,sword;
        for(int step=0;step<=80;++step) {
            const float angle=step*.16f;
            link.model.joints=nativeJoints;
            link.morph.quaternions[10]=dual::from_euler({angle,-angle*.7f,angle*.4f});
            s.stow.progress=progress;
            samePose(hand_mount(&link,true),gripBefore);
            // Main sword still consumes the actual animated quaternion.
            assert(hand_mount(&link,false).q.x==link.morph.quaternions[10].x);
            after_arms(nullptr,&args,nullptr,nullptr);
            if(step==0) {wrist=link.model.joints[14];sword=s.rightSword;}
            else {samePose(link.model.joints[14],wrist);samePose(s.rightSword,sword);}
            for(int joint=0;joint<35;++joint)
                if(joint<11||joint>15)samePose(link.model.joints[joint],nativeJoints[joint]);
        }
    }
    link.field_0x3198=1;link.mUnderFrameCtrl[0].frame=2;
    update_stow(&link,false);assert(s.stow.active);samePose(hand_mount(&link,true),gripBefore);
    link.mProcID=daAlink_c::PROC_WAIT;link.mEquipItem=dItemNo_NONE_e;
    update_stow(&link,false);assert(s.stow.release==1);samePose(hand_mount(&link,true),gripBefore);
    for(int i=0;i<7;++i)update_stow(&link,false);
    assert(s.stow.release==0);
    // Reversed draw also snapshots the grip before activating the new motion.
    s.draw=0;const Pose drawMount=hand_mount(&link,true);start_draw(&link,false);
    samePose(s.stow.mount,drawMount);

    // Charge is authored in the real local rig: +X is bone length, the
    // elbow uses local Z. Native skinning/morphing receives the whole chain.
    s.stow={};s.guard=0;s.draw=1;s.charge=0;link.mEquipItem=0x103;
    link.mProcID=daAlink_c::PROC_CUT_LARGE_JUMP_CHARGE;link.guard=true;
    for(int tick=0;tick<7;++tick) {
        ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
        const float weight=s.charge;after_matrix(nullptr,&args,nullptr,nullptr);
        assert(s.charge==weight&&s.guard==0&&!s.stow.active);
    }
    assert(s.charge==1);original.armRig=true;
    for(int proc:{daAlink_c::PROC_CUT_LARGE_JUMP_CHARGE,daAlink_c::PROC_CUT_TURN_MOVE}) {
        link.mProcID=proc;link.mProcVar2.field_0x300c=1;
        ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);assert(s.charge==1&&jump_charge(&link));
        for(auto type:{SecondSword::Wooden,SecondSword::Ordon,SecondSword::Master}) {
            s.swordType=type;
            for(float frame:{0.f,10.f,30.f,60.f}) {
                original.frame=frame;
                before_model_calc(nullptr,&args,nullptr,nullptr);assert(s_calculating);
                std::array<J3DTransformInfo,4> arm;
                for(auto* packs:{&link.mNowAnmPackUnder,&link.mNowAnmPackUpper})
                for(auto& pack:*packs) for(int joint=0;joint<35;++joint) {
                    J3DTransformInfo native,actual;
                    original.getTransform(joint,&native);pack.value->getTransform(joint,&actual);
                    assert(actual.mTranslate.x==native.mTranslate.x&&actual.mTranslate.y==native.mTranslate.y&&actual.mTranslate.z==native.mTranslate.z);
                    assert(actual.mScale.x==native.mScale.x&&actual.mScale.y==native.mScale.y&&actual.mScale.z==native.mScale.z);
                    if(joint>=11&&joint<=14)arm[joint-11]=actual;
                    else assert(actual.mRotation.x==native.mRotation.x&&actual.mRotation.y==native.mRotation.y&&actual.mRotation.z==native.mRotation.z);
                }
                constexpr float radians=3.14159265358979323846f/180;
                const auto elbow=joint_rotation(arm[2]);
                // A pure 75-degree hinge: no inherited X/Y twist at the elbow.
                samePose({elbow,{}},{dual::from_euler({0,0,75*radians}),{}});
                samePose({joint_rotation(arm[3]),{}},{dual::from_euler({35*radians,0,0}),{}});
                for(float yaw:{0.f,1.7f,-2.8f}) {
                    // Root/chest bind orientation and real native joint offsets.
                    Pose chest{dual::multiply(dual::from_euler({0,yaw,0}),dual::from_euler({90*radians,0,90*radians})),{80,143,-120}};
                    std::array<Pose,4> posed;
                    for(int bone=0;bone<4;++bone) {
                        const auto& t=arm[bone];
                        posed[bone]=dual::compose(bone?posed[bone-1]:chest,
                            Pose{joint_rotation(t),{t.mTranslate.x,t.mTranslate.y,t.mTranslate.z}});
                    }
                    assert(std::abs(dual::length(posed[2].p-posed[1].p)-29)<.003f);
                    assert(std::abs(dual::length(posed[3].p-posed[2].p)-26.5f)<.003f);
                    const Vec offset=dual::rotate(dual::conjugate(dual::from_euler({0,yaw,0})),posed[3].p-posed[1].p);
                    assert(offset.x<-10&&offset.y>10&&offset.y<20&&offset.z>35); // above and ahead of the thigh
                    // Another 35 degrees of shoulder swing lifts the chain without
                    // changing the accepted local elbow and wrist rotations.
                    const Vec previous{-15.155f,-11.940f,39.610f};
                    assert(offset.z>previous.z-1&&offset.y>previous.y+20);
                    const Pose relative=dual::compose(dual::inverse(posed[1]),posed[2]);
                    samePose(relative,{elbow,{29,0,0}});
                }
                after_model_calc(nullptr,&args,nullptr,nullptr);assert(!s_calculating);
                for(auto& pack:link.mNowAnmPackUnder)assert(pack.value==&original);
                for(auto& pack:link.mNowAnmPackUpper)assert(pack.value==&original);
            }
        }
    }
    original.armRig=false;
    // Ordinary spin charge must not inherit the Jump Strike override.
    link.mProcVar2.field_0x300c=0;++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
    assert(!jump_charge(&link)&&s.charge==0);
    for(int boundary=0;boundary<8;++boundary) {
        s.charge=1;link.mProcID=daAlink_c::PROC_CUT_LARGE_JUMP_CHARGE;
        if(boundary==0)link.mProcID=daAlink_c::PROC_CUT_LARGE_JUMP;
        if(boundary==1)link.mProcID=daAlink_c::PROC_LARGE_DAMAGE;
        if(boundary==2)link.horse=true;
        if(boundary==3)link.event=true;
        if(boundary==4)glidingOwner=&link;
        if(boundary==5)setting=false;
        if(boundary==6)link.human=false;
        if(boundary==7)link.mEquipItem=dItemNo_BOW_e;
        ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);assert(s.charge==0);
        link.horse=link.event=false;glidingOwner=nullptr;setting=true;link.human=true;link.mEquipItem=0x103;
    }
    link.model.base={};link.model.joints=nativeJoints;link.guard=false;
    link.mProcID=daAlink_c::PROC_WAIT;s.swordType=SecondSword::Ordon;
    s.charge=1;s.stow={};s.draw=1;s.guard=0;
    for(int i=0;i<7;++i) {const float previous=s.charge;++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);assert(s.charge<=previous);}
    assert(s.charge==0);
    ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
    // Mounted block keeps the native lean and every arm joint, even when
    // mounting interrupts an on-foot guard, draw, stow or release blend.
    for(int item:std::array<int,4>{0x103,dItemNo_NONE_e,dItemNo_BOW_e,dItemNo_PACHINKO_e}) {
        for(bool drawing:{false,true}) {
            link.horse=true;link.guard=true;link.mEquipItem=item;
            s.guard=1;s.draw=1;s.haveGuardBody=true;
            s.stow.active=true;s.stow.drawing=drawing;s.stow.release=1;
            s.forcedBlade=true;
            for(int frame=0;frame<30;++frame) {
                link.model.joints=nativeJoints;
                ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
                assert(s.active && s.enabled && s.guard==0 && !s.haveGuardBody);
                assert(!s.stow.active && s.stow.release==0);
                before_guard_attack(nullptr,&args,nullptr,nullptr);assert(!s.haveGuardBody);
                before_model_calc(nullptr,&args,nullptr,nullptr);assert(!s_calculating);
                after_arms(nullptr,&args,nullptr,nullptr);after_items(nullptr,&args,nullptr,nullptr);
                assert(!s.forcedBlade);
                for(int joint=0;joint<35;++joint) {
                    const auto& a=link.model.joints[joint];const auto& b=nativeJoints[joint];
                    assert(a.p.x==b.p.x&&a.p.y==b.p.y&&a.p.z==b.p.z);
                    assert(a.q.x==b.q.x&&a.q.y==b.q.y&&a.q.z==b.q.z&&a.q.w==b.q.w);
                }
            }
            // A fresh mounted block press must not start a hip draw either.
            link.guard=false;++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
            link.guard=true;++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
            assert(s.guard==0 && !s.stow.active && s.stow.release==0);
            link.horse=false;
            ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
            assert(s.guard>0 && s.guard<1); // on-foot block resumes
        }
    }
    // Deploying Glide from drawn swords must immediately free both arms,
    // even with guard held or a draw/stow/release transition already running.
    for(bool drawing:{false,true}) for(bool guardHeld:{false,true}) {
        link.mEquipItem=dItemNo_NONE_e;link.guard=guardHeld;glidingOwner=&link;
        s.stow.active=true;s.stow.drawing=drawing;s.stow.release=1;
        s.draw=1;s.guard=1;s.sheathTilt=1;s.haveGuardBody=true;
        s.forcedBlade=true;
        for(int frame=0;frame<3;++frame) {
            link.model.joints=nativeJoints;
            ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
            assert(s.enabled&&!s.active&&!s.mirror&&!s.haveGuardBody);
            assert(!s.stow.active&&s.stow.release==0&&s.draw==0&&s.guard==0&&s.sheathTilt==0);
            after_arms(nullptr,&args,nullptr,nullptr);after_items(nullptr,&args,nullptr,nullptr);
            assert(!s.forcedBlade&&s.shieldTick==~0u);
            for(int joint=0;joint<35;++joint) {
                const auto& a=link.model.joints[joint];const auto& b=nativeJoints[joint];
                assert(a.p.x==b.p.x&&a.p.y==b.p.y&&a.p.z==b.p.z);
                assert(a.q.x==b.q.x&&a.q.y==b.q.y&&a.q.z==b.q.z&&a.q.w==b.q.w);
            }
            assert(dual::length(s.rightSword.p-s.hipSword.p)<0.001f);
        }
        glidingOwner=nullptr;link.guard=false;
        ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
        assert(s.active&&!s.stow.active&&s.stow.release==0&&s.draw==0);
        link.mEquipItem=0x103;
        ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
        assert(s.stow.active&&s.stow.drawing); // normal drawing resumes after Glide
    }
    for(int item:{dItemNo_PACHINKO_e,dItemNo_BOW_e,dItemNo_BOMB_ARROW_e,dItemNo_HAWK_ARROW_e,
                  dItemNo_HOOKSHOT_e,dItemNo_W_HOOKSHOT_e,dItemNo_COPY_ROD_e,dItemNo_COPY_ROD_2_e,
                  dItemNo_BOOMERANG_e,dItemNo_KANTERA_e,dItemNo_KANTERA2_e}) {
        link.mEquipItem=item;link.guard=true;s.guard=0;s.draw=0;s.stow={};
        primary.base={{},{500,600,700}};
        // Also discard a synthetic Master Sword left over from empty-handed guard.
        s.forcedBlade=true;const int hidden=link.swordHidden;
        for(int frame=0;frame<28;++frame) {
            link.model.joints=nativeJoints;
            ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
            after_arms(nullptr,&args,nullptr,nullptr);after_items(nullptr,&args,nullptr,nullptr);
            assert(link.mEquipItem==item&&!s.forcedBlade&&link.swordShown==0);
            assert(primary.base.p.x==500&&primary.base.p.y==600&&primary.base.p.z==700);
            for(int joint=6;joint<=10;++joint) {
                const auto& a=link.model.joints[joint];const auto& b=nativeJoints[joint];
                assert(a.p.x==b.p.x&&a.p.y==b.p.y&&a.p.z==b.p.z);
                assert(a.q.x==b.q.x&&a.q.y==b.q.y&&a.q.z==b.q.z&&a.q.w==b.q.w);
            }
        }
        assert(s.guard==1&&s.draw==1&&!s.stow.active);
        assert(link.swordHidden==hidden+1);
        assert(dual::length(link.model.joints[14].p-nativeJoints[14].p)>1);
        // Releasing guard returns only the Ordon sword to the hip.
        link.guard=false;++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
        assert(s.stow.active&&!s.stow.drawing);
        for(int frame=0;frame<30;++frame){++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);}
        assert(s.guard==0&&s.draw==0&&!s.stow.active&&link.mEquipItem==item);
        // The same one-handed mode still yields immediately to knockdown.
        link.guard=true;link.mProcID=daAlink_c::PROC_LARGE_DAMAGE_UP;s.guard=1;
        ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);
        assert(s.guard==0&&!s.stow.active&&s.stow.release==0);
        link.mProcID=daAlink_c::PROC_WAIT;
    }
    // Native shield bash lifts its elbow. Item guard must keep its own lower,
    // outward bend for the entire thrust/recovery, even after Link turns.
    for(int item:{dItemNo_KANTERA_e,dItemNo_COPY_ROD_e,dItemNo_BOW_e}) {
        link.mEquipItem=item;link.mProcID=daAlink_c::PROC_GUARD_ATTACK;
        s.guard=1;s.draw=1;s.stow={};
        for(float yaw:{0.f,1.7f}) {
            const Pose world{{0,std::sin(yaw*.5f),0,std::cos(yaw*.5f)},{80,40,-120}};
            link.model.base=world;
            Vec previous{};
            for(int step=0;step<=80;++step) {
                link.model.joints=nativeJoints;
                link.model.joints[13].p={-32,151,0}; // Elbow above the shoulder.
                link.model.joints[14].p={-24,125,22};
                for(auto& joint:link.model.joints) joint=dual::compose(world,joint);
                const auto before=link.model.joints;
                const float upperLength=dual::length(before[13].p-before[12].p);
                const float lowerLength=dual::length(before[14].p-before[13].p);
                link.mUnderFrameCtrl[0].frame=2+step*.2f;
                after_arms(nullptr,&args,nullptr,nullptr);
                const auto& joints=link.model.joints;
                const auto shoulder=dual::compose(dual::inverse(world),joints[12]).p;
                const auto elbow=dual::compose(dual::inverse(world),joints[13]).p;
                assert(elbow.y<shoulder.y);
                const auto hand=dual::compose(dual::inverse(world),joints[14]).p;
                const Vec direction=dual::unit(hand-shoulder);
                const Vec bend=elbow-shoulder-direction*dual::dot(elbow-shoulder,direction);
                assert(bend.y<0); // Bend below the shoulder-to-wrist line, not over it.
                if(step)assert(dual::length(elbow-previous)<2.f);
                previous=elbow;
                assert(std::abs(dual::length(joints[13].p-joints[12].p)-upperLength)<.005f);
                assert(std::abs(dual::length(joints[14].p-joints[13].p)-lowerLength)<.005f);
                for(int joint=6;joint<=10;++joint) {
                    assert(dual::length(joints[joint].p-before[joint].p)<.001f);
                    assert(joints[joint].q.x==before[joint].q.x&&joints[joint].q.y==before[joint].q.y&&
                           joints[joint].q.z==before[joint].q.z&&joints[joint].q.w==before[joint].q.w);
                }
            }
        }
    }
    link.model.base={};
    // Switching directly from cross guard to an item cannot reuse its body override.
    link.mEquipItem=dItemNo_COPY_ROD_e;link.mProcID=daAlink_c::PROC_GUARD_ATTACK;s.haveGuardBody=true;
    before_model_calc(nullptr,&args,nullptr,nullptr);assert(!s_calculating);
    ++s.tick;after_matrix(nullptr,&args,nullptr,nullptr);assert(!s.haveGuardBody);
    // Empty-handed guard still supplies the main sword, then an item hides it once.
    link.mEquipItem=dItemNo_NONE_e;s.guard=1;
    after_items(nullptr,&args,nullptr,nullptr);assert(s.forcedBlade&&link.swordShown==1);
    link.mEquipItem=dItemNo_KANTERA_e;
    after_items(nullptr,&args,nullptr,nullptr);assert(!s.forcedBlade&&link.swordShown==1);
    link.mEquipItem=0x103;link.mProcID=daAlink_c::PROC_WAIT;
    // The invisible shield must retain its original defensive facing even
    // though setItemMatrix has attached it to the sword-oriented right hand.
    J3DModel shieldModel;link.mShieldModel=&shieldModel;link.guard=true;
    s.guard=1;s.draw=1;s.stow={};link.mProcID=daAlink_c::PROC_WAIT;
    const auto normal=[](Pose p){return dual::rotate(p.q,{0,0,1});};
    const auto shieldHit=[&](Pose shield,float attackAngle,float halfRange) {
        const Vec n=normal(shield);const float facing=std::atan2(n.x,n.z);
        return std::abs(std::remainder(attackAngle-facing,2*3.14159265358979323846f))<=halfRange;
    };
    for(int item:std::array<int,5>{0x103,dItemNo_NONE_e,dItemNo_BOW_e,dItemNo_COPY_ROD_e,dItemNo_KANTERA_e}) {
        link.mEquipItem=item;
        for(float yaw:{0.f,1.3f,-2.8f}) {
            const Pose world{{0,std::sin(yaw*.5f),0,std::cos(yaw*.5f)},{90,30,-70}};
            link.model.base=world;link.model.joints=nativeJoints;
            // Native shield attachment includes the current body/arm animation.
            link.model.joints[15]={{},{-20,110,20}};
            for(auto& joint:link.model.joints)joint=dual::compose(world,joint);
            const Pose vanillaShield=link.model.joints[15];
            ++s.tick;after_arms(nullptr,&args,nullptr,nullptr);
            assert(s.shieldTick==s.tick);
            // The host attaches the shield after our arm IK, rotating the cone.
            shieldModel.base=link.model.joints[15];
            assert(dual::length(normal(shieldModel.base)-normal(vanillaShield))>.1f);
            const auto swordHand=link.model.joints[14],swordItem=link.model.joints[15];
            assert(before_collision(nullptr,&args,nullptr,nullptr)==HOOK_CONTINUE);
            assert(dual::length(normal(shieldModel.base)-normal(vanillaShield))<.001f);
            assert(dual::length(shieldModel.base.p-vanillaShield.p)<.001f);
            // Sweep frontal/flanking/rear attacks against the same native cone;
            // test multiple limits without replacing or expanding those limits.
            for(float range:{.5f,1.f,1.5f}) for(int degree=-180;degree<=180;++degree) {
                const float attack=yaw+degree*3.14159265358979323846f/180;
                assert(shieldHit(shieldModel.base,attack,range)==shieldHit(vanillaShield,attack,range));
            }
            assert(shieldHit(shieldModel.base,yaw,1.f));
            assert(!shieldHit(shieldModel.base,yaw+3.14159265358979323846f,1.f));
            assert(dual::length(link.model.joints[14].p-swordHand.p)==0);
            assert(dual::length(link.model.joints[15].p-swordItem.p)==0&&link.mEquipItem==item);
            // No stale sample and no writes while released, disabled or changing shields.
            const Pose untouched{{},{900,800,700}};
            for(int condition=0;condition<4;++condition) {
                shieldModel.base=untouched;
                if(condition==0)++s.tick;
                if(condition==1)link.guard=false;
                if(condition==2)s.active=false;
                if(condition==3)link.mShieldChangeWaitTimer=1;
                before_collision(nullptr,&args,nullptr,nullptr);
                assert(shieldModel.base.p.x==900&&shieldModel.base.p.y==800&&shieldModel.base.p.z==700);
                if(condition==0)--s.tick;
                link.guard=true;s.active=true;link.mShieldChangeWaitTimer=0;
            }
        }
    }
    link.model.base={};link.mEquipItem=0x103;
    // Preview equipment follows newly evaluated menu joints rather than the
    // previous gameplay item matrices, without changing combat transition state.
    J3DModel previewSword,previewSheath;s.sword=&previewSword;s.sheath=&previewSheath;
    link.model.joints[9]={{},{10,20,30}};link.model.joints[10]={{},{11,22,33}};
    link.model.joints[14]={{},{100,200,300}};link.model.joints[16]={{},{40,50,60}};
    s.rightSword={{},{-100,-200,-300}};const auto gameplay=s.rightSword;
    status_item_matrices(&link);
    assert(previewSword.base.p.x==101&&previewSword.base.p.y==202&&previewSword.base.p.z==297);
    const auto sheathBefore=previewSheath.base.p;
    link.model.joints[14].p.x+=50;link.model.joints[16].p.x+=50;
    status_item_matrices(&link);
    assert(previewSword.base.p.x==151&&std::fabs(previewSheath.base.p.x-sheathBefore.x-50)<.001f);
    assert(s.rightSword.p.x==gameplay.p.x&&s.rightSword.p.z==gameplay.p.z);
    // Preview calibration follows actor orientation, not camera/world X.
    const Pose previewBase=previewSheath.base;
    const Pose previewBlade=previewSword.base;
    for(const Vec angles:{Vec{0,1.57079632679f,0},Vec{.2f,-.8f,.1f}}) {
        link.model.base.q=dual::from_euler(angles);
        status_item_matrices(&link);
        const Vec outward=dual::rotate(link.model.base.q,{1.5f,0,0});
        assert(dual::length(previewSheath.base.p-previewBase.p-outward+Vec{1.5f,0,0})<.001f);
        assert(dual::length(previewSword.base.p-previewBlade.p)<.001f);
    }
    link.model.base={};
    // Same mesh roll in gameplay and Collection, with no wrist/IK mutation.
    assert(dual::length(dual::rotate(previewSword.base.q,{0,1,0})-Vec{0,-1,0})<.001f);
    const auto handsBefore=link.model.joints;
    const Pose hipMount=local(-18.5f,.14f,12.2f,0,33.1f);
    s.owner=&link;s.enabled=true;s.active=true;s.forcedBlade=false;
    for(auto type:{SecondSword::Wooden,SecondSword::Ordon,SecondSword::Master}) {
        s.swordType=type;s.sheath=type==SecondSword::Wooden?nullptr:&previewSheath;
        for(const Pose grip:{Pose{{},{4,5,6}},dual::cross_guard_blade(true,0),
                              dual::cross_guard_blade(true,1),Pose{dual::from_euler({.4f,.2f,1.1f}),{8,9,10}}}) {
            link.model.base.q=grip.q;
            s.rightSword=grip;s.hipSword=grip;
            after_items(nullptr,&args,nullptr,nullptr);
            assert(dual::length(previewSword.base.p-grip.p)<.001f);
            assert(dual::length(dual::rotate(previewSword.base.q,{1,0,0})-dual::rotate(grip.q,{1,0,0}))<.001f);
            assert(dual::length(dual::rotate(previewSword.base.q,{0,1,0})+dual::rotate(grip.q,{0,1,0}))<.001f);
            if(s.sheath) {
                const Pose inserted=dual::compose(previewSheath.base,hipMount);
                const Vec outward=dual::rotate(link.model.base.q,{1.5f,0,0});
                assert(dual::length(inserted.p-previewSword.base.p-outward)<.001f);
                assert(dual::length(dual::rotate(inserted.q,{0,1,0})-dual::rotate(previewSword.base.q,{0,1,0}))<.001f);
            }
            for(int j=6;j<=15;++j) {
                assert(dual::length(link.model.joints[j].p-handsBefore[j].p)<.001f);
                assert(dual::length(dual::rotate(link.model.joints[j].q,{0,1,0})-dual::rotate(handsBefore[j].q,{0,1,0}))<.001f);
            }
        }
    }
}
'''

loader_fixture = r'''
#include "dual_wield_sword.hpp"
using namespace dawnlight;
#include <cassert>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <map>
#include <string>
#include <array>
using u32=std::uint32_t;
struct J3DTexMtx {
    struct Info {float scrollX=0,scrollY=0,worldX=0;} info;
    auto& getTexMtxInfo(){return info;}
};
struct Shape {bool visible=true;void hide(){visible=false;}void show(){visible=true;}};
struct Tev {
    struct Order {int map;int getTexMap(){return map;}};
    std::array<Order,2> orders{{{0},{3}}};int count=2;
    int getTevStageNum(){return count;}
    auto getTevOrder(int i){return &orders.at(i);}
};
struct Tex {
    std::array<J3DTexMtx*,2> matrices{};int count=2;
    int getTexGenNum(){return count;}
    auto getTexMtx(int i){return matrices.at(i);}
};
struct Material {
    Shape shape;Tev tev;Tex tex;
    auto getTevBlock(){return &tev;}auto getTexGenBlock(){return &tex;}
    auto getShape(){return &shape;}
};
struct ModelData {
    J3DTexMtx warp;std::array<Material,2> materials;
    int joints=35,materialCount=2;
    ModelData(){for(auto& m:materials)m.tex.matrices[1]=&warp;}
    int getJointNum(){return joints;}std::uint16_t getMaterialNum(){return materialCount;}
    auto getMaterialNodePointer(int i){return &materials.at(i);}
} data;
struct J3DModel {ModelData* data;auto getModelData(){return data;}} model{&data};
struct daAlink_c {
    J3DModel* mSheathModel=nullptr;
    bool preview=false,human=true;
    J3DModel* mSwordModel=&model;J3DModel* mpLinkModel=&model;
    void* field_0x2060=&model;
    bool wooden=false,swordOwned=true;
    bool checkWolf(){return !human;}
    bool checkSwordGet(){return swordOwned;}
    bool checkWoodSwordEquip(){return wooden;}
    bool checkStatusWindowDraw(){return preview;}
};
bool equipped=true;
bool dual_wield_equipped(){return equipped;}
struct Heap {
    std::array<char,64> bytes{};bool fail=false;
    void* alloc(u32 size,int alignment){assert(size==64 && alignment==32);return fail?nullptr:bytes.data();}
} heap;
struct {
    Heap* heap;daAlink_c* owner=nullptr;J3DModel* sword=nullptr;J3DModel* sheath=nullptr;
    bool enabled=false,active=false;float draw=0;SecondSword swordType=SecondSword::Ordon;
} s{&heap};
struct JKRArchive {
    std::map<std::string,std::array<char,64>> files;
    std::string directory;
    void* getResource(const char* path) {
        auto it=files.find(directory+path);
        return it==files.end()?nullptr:it->second.data();
    }
    void* getResource(u32 type,const char* name) {
        assert(type==0);
        for(auto& [path,bytes]:files) {
            if(path.substr(path.find_last_of('/')+1)==name)return bytes.data();
        }
        return nullptr;
    }
    u32 getExpandedResSize(void*){return 64;}
};
std::string warning;
struct Log {void warn(void*,const char* message){warning=message;}} logService;
Log* svc_log=&logService;void* mod_ctx=nullptr;
bool environment=false;
struct dRes_info_c {
    static ModelData* loaderBasicBmd(u32 tag,void* raw) {
        assert((tag==0x424D5752 || tag==0x424D5745) && raw==heap.bytes.data());
        environment=tag==0x424D5745;
        assert(std::memcmp(raw,"J3D2bmd3",8)==0);
        static_cast<char*>(raw)[8]=42; // Native loader modifies only the private copy.
        onWarpMaterial(&data); // BMWR initially enables its warp stage.
        return &data;
    }
    static void onWarpMaterial(ModelData* d) {
        for(auto& m:d->materials) {
            if(m.tev.getTevOrder(m.tev.count-1)->getTexMap()==3)break;
            ++m.tev.count;++m.tex.count;
        }
    }
    static void offWarpMaterial(ModelData* d) {
        for(auto& m:d->materials) {
            if(m.tev.getTevOrder(m.tev.count-1)->getTexMap()!=3)break;
            --m.tev.count;--m.tex.count;
        }
    }
};
bool createFails=false;
J3DModel* mDoExt_J3DModel__create(ModelData* d,u32 flags,u32 diff) {
    assert(d==&data && flags==(environment?0u:0x80000u) && diff==0x13000684);
    for(auto& m:d->materials)assert(m.tev.count==2 && m.tex.count==2);
    return createFails?nullptr:&model;
}
'''
loader_fixture += function("model_failure") + function("copy_model", "J3DModel*")
loader_fixture += r'''
bool active(daAlink_c* link){return s.owner==link && s.active && s.sword && (s.swordType==SecondSword::Wooden || s.sheath);}
'''
loader_fixture += function("models_ready", "bool")
loader_fixture += function("human", "bool") + function("show_guard_blade")
loader_fixture += function("warp_texture", "J3DTexMtx*") + function("equipment_visible", "bool") + function("sync_equipment_materials")
loader_fixture += r'''
int main() {
    JKRArchive archive;
    for(const char* name:{"al_swa.bmd","al_poda.bmd"}) {
        auto& bytes=archive.files[std::string("bmwr/")+name];
        std::memcpy(bytes.data(),"J3D2bmd3",8);
    }
    for(const char* directory:{"","bck/","bmwr/"}) {
        archive.directory=directory;
        for(const char* name:{"al_swa.bmd","al_poda.bmd"}) {
            assert(copy_model(&archive,name)==&model);
            assert(archive.files.at(std::string("bmwr/")+name)[8]==0);
            assert(!warp_texture(&model)); // no world-dependent clipping after load
        }
    }
    for(auto choice:{SecondSword::Wooden,SecondSword::Ordon,SecondSword::Master}) {
        const auto assets=second_sword_assets(choice);
        auto& bytes=archive.files[std::string("bmwr/")+assets.sword];
        std::memcpy(bytes.data(),"J3D2bmd3",8);
        assert(copy_model(&archive,assets.sword,assets.environmentMapped)==&model);
        assert(environment==assets.environmentMapped);
    }
    assert(warning.empty());
    assert(!copy_model(&archive,"missing.bmd"));
    assert(warning.find("missing.bmd: resource not found")!=std::string::npos);
    heap.fail=true;assert(!copy_model(&archive,"al_swa.bmd"));
    assert(warning.find("allocation failed")!=std::string::npos);heap.fail=false;
    createFails=true;assert(!copy_model(&archive,"al_swa.bmd"));
    assert(!warp_texture(&model));createFails=false;
    archive.files.at("bmwr/al_swa.bmd")[0]='X';
    assert(!copy_model(&archive,"al_swa.bmd"));
    assert(warning.find("invalid BMD header")!=std::string::npos);

    ModelData nativeData,swordData,sheathData;
    J3DModel native{&nativeData},sword{&swordData},sheath{&sheathData};
    daAlink_c link{&native},other{&native};
    link.mSwordModel=&native;
    // Custom Wooden Sword uses the ordinary native wood backing item. It must
    // be eligible, and guard must hide its stowed duplicate, not reveal it.
    assert(human(&link));link.wooden=true;assert(human(&link));
    nativeData.materials[0].shape.visible=true;nativeData.materials[1].shape.visible=true;
    show_guard_blade(&link);
    assert(nativeData.materials[0].shape.visible&&!nativeData.materials[1].shape.visible);
    link.wooden=false;nativeData.materials[0].shape.visible=false;show_guard_blade(&link);
    assert(nativeData.materials[0].shape.visible);
    link.swordOwned=false;assert(!human(&link));link.swordOwned=true;
    link.human=false;assert(!human(&link));link.human=true;
    data.joints=12;assert(!human(&link));data.joints=35;
    nativeData.materialCount=1;link.wooden=true;show_guard_blade(&link);
    nativeData.materialCount=2;link.wooden=false;
    s.owner=&link;s.sword=&sword;s.sheath=&sheath;s.enabled=s.active=true;
    dRes_info_c::offWarpMaterial(&nativeData);
    // Fully sheathed: only the secondary blade disappears.
    sync_equipment_materials(&link);
    assert(!swordData.materials[0].shape.visible);
    assert(swordData.materials[1].shape.visible && sheathData.materials[0].shape.visible);
    assert(nativeData.materials[0].shape.visible);
    s.draw=1;sync_equipment_materials(&link);assert(swordData.materials[0].shape.visible);
    assert(equipment_visible(&link) && !equipment_visible(&other));
    // Preview updates do not run gameplay setMatrix: live menu selection wins
    // over stale gameplay enabled/active/draw state, and never inherits a warp.
    link.preview=true;s.enabled=false;s.active=false;s.draw=0;
    assert(equipment_visible(&link));sync_equipment_materials(&link);
    assert(swordData.materials[0].shape.visible);
    assert(swordData.materials[0].tev.count==1);
    equipped=false;assert(!equipment_visible(&link));equipped=true;
    link.human=false;assert(!equipment_visible(&link));link.human=true;
    link.preview=false;s.enabled=true;s.active=true;s.draw=1;
    // An arrival can already be in progress when the private models appear.
    for(int cycle=0;cycle<3;++cycle) {
        dRes_info_c::onWarpMaterial(&nativeData);
        for(int frame=0;frame<80;++frame) {
            nativeData.warp.info={frame*.15f,4.6f-frame*.06f,float(cycle*1000)};
            sync_equipment_materials(&link);
            for(auto* d:{&swordData,&sheathData}) {
                assert(d->warp.info.scrollX==nativeData.warp.info.scrollX);
                assert(d->warp.info.scrollY==nativeData.warp.info.scrollY);
                assert(d->warp.info.worldX==nativeData.warp.info.worldX);
                for(auto& m:d->materials)assert(m.tev.count==2 && m.tex.count==2);
            }
        }
        s.active=false;assert(equipment_visible(&link)); // scripted warp, arms untouched
        sync_equipment_materials(&link);assert(!swordData.materials[0].shape.visible);
        s.enabled=false;assert(!equipment_visible(&link));s.enabled=true;
        dRes_info_c::offWarpMaterial(&nativeData);
        assert(equipment_visible(&link)); // dialogue/cutscenes retain the hip equipment
        sync_equipment_materials(&link);
        assert(!swordData.materials[0].shape.visible && swordData.materials[1].shape.visible);
        assert(sheathData.materials[0].shape.visible);
        s.active=true;
        for(int frame=0;frame<5;++frame)sync_equipment_materials(&link);
        for(auto* d:{&swordData,&sheathData,&nativeData})
            for(auto& m:d->materials)assert(m.tev.count==1 && m.tex.count==1);
        assert(swordData.materials[0].shape.visible);
    }
    // Wooden offhand has no metal scabbard and stays visible when stowed.
    s.swordType=SecondSword::Wooden;s.sheath=nullptr;s.draw=0;
    assert(models_ready() && equipment_visible(&link));
    sync_equipment_materials(&link);
    assert(swordData.materials[0].shape.visible && swordData.materials[1].shape.visible);
    s.draw=1;sync_equipment_materials(&link);
    assert(swordData.materials[0].shape.visible && !swordData.materials[1].shape.visible);
    link.preview=true;s.draw=0;sync_equipment_materials(&link);
    assert(!swordData.materials[1].shape.visible);link.preview=false;
    // Master uses the metal blade/sheath rule; a missing required sheath is not ready.
    s.swordType=SecondSword::Master;assert(!models_ready());s.sheath=&sheath;
    assert(models_ready());sync_equipment_materials(&link);
    assert(!swordData.materials[0].shape.visible);
    s.draw=1;sync_equipment_materials(&link);assert(swordData.materials[0].shape.visible);

}
'''

with tempfile.TemporaryDirectory() as folder:
    temp = Path(folder)
    for name, content in [
        ("JSystem/J3DGraphAnimator/J3DAnimation.h", animation_api),
        ("JSystem/J3DGraphBase/J3DTransform.h", "#pragma once\n"),
    ]:
        path = temp / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)
    (temp / "native.cpp").write_text(fixture)
    (temp / "loader.cpp").write_text(loader_fixture)
    for name, path in [("math", root / "tests/dual_wield_math_test.cpp"),
                       ("native", temp / "native.cpp"), ("loader", temp / "loader.cpp")]:
        executable = temp / name
        subprocess.run(["c++", "-std=c++17", "-Wall", "-Wextra", "-I", str(temp),
                        "-I", str(root / "src"), str(path), "-o", str(executable)], check=True)
        subprocess.run([str(executable)], check=True)
print("Dual Wield math, animation borrowing, hand contacts, lifecycle, blade visibility and warp materials: OK")

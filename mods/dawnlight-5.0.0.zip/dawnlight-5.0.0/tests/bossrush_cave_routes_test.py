"""Exercise the production Cave/arena transition hook with engine state stubs."""
from pathlib import Path
import re
import subprocess
import tempfile

source = (Path(__file__).resolve().parents[1] / "src/new_save_modes.cpp").read_text()


def function(name, source=source):
    match = re.search(r"^(?:void|bool|HookAction) " + name + r"\([^\n]*\) \{", source, re.M)
    assert match, name
    depth = 0
    start = source.index("{", match.start())
    for end in range(start, len(source)):
        depth += (source[end] == "{") - (source[end] == "}")
        if depth == 0:
            return source[match.start():end + 1]
    raise AssertionError(name)


stubs = r'''
#include <cassert>
#include <cstring>
#include <string>
#include <iostream>
#include <any>
using s8 = signed char; using s16 = short; using s32 = int; using BOOL = int;
using u8 = unsigned char;
constexpr int TRUE=1, FALSE=0;
#include <unordered_set>
#include <vector>
using ActorId = unsigned; using fpc_ProcID = unsigned;
constexpr fpc_ProcID fpcM_ERROR_PROCESS_ID_e=~0u;
using process_method_func = int (*)(void*);
struct process_method_class { process_method_func create_method, delete_method, execute_method; };
struct process_class { ActorId id; bool initialized=false; bool validProcess=true; };
struct fopAc_ac_c : process_class {
    const process_method_class* sub_method=nullptr;
    int profile=0;
    struct { short y=0; } shape_angle;
    struct { decltype(shape_angle) angle; } current;
};
struct e_tk_class : fopAc_ac_c { int mExecuteState=0; };
struct e_tk2_class : fopAc_ac_c { int mActionTimer[4]{}; };
struct daE_ZS_c : fopAc_ac_c { int field_0x671=0; };
ActorId fpcM_GetID(const void* p) { return static_cast<const process_class*>(p)->id; }
ActorId fopAcM_GetID(fopAc_ac_c* p) { return p->id; }
bool is_base_process(void* p) { return p && static_cast<process_class*>(p)->validProcess; }
bool is_actor_process(void* p) { return is_base_process(p) && static_cast<process_class*>(p)->initialized; }
int fopAcM_GetName(fopAc_ac_c* p) { return p->profile; }
std::unordered_set<ActorId> s_testActors;
std::vector<std::pair<void*, bool>> s_testProcessStack;
struct ModContext {}; struct dSv_save_c {};
struct dMenu_save_c { int mEndStatus=2; int getEndStatus() { return mEndStatus; } };
struct dGameover_c { bool mIsDemoSave=false; dMenu_save_c* dMs_c=nullptr; };
int gameOverStatus=0;
int dComIfGp_getGameoverStatus() { return gameOverStatus; }
int gameOverType=0;
int dMeter2Info_getGameOverType() { return gameOverType; }
struct dSv_memBit_c { enum { STAGE_BOSS_ENEMY=3, STAGE_BOSS_DEMO=5, STAGE_BOSS_ENEMY_2=7 }; };
enum { fpcNm_B_TN_e, fpcNm_TBOX_e, fpcNm_TBOX2_e, fpcNm_Obj_Carry_e,
       fpcNm_TAG_EVT_e, fpcNm_TAG_MSG_e, fpcNm_TAG_EVTAREA_e, fpcNm_TAG_EVTMSG_e,
       testDoorProfile, fpcNm_E_TK_e, fpcNm_E_TK2_e, fpcNm_E_ZS_e };
struct dStage_objectNameInf { int procname; };
enum HookAction { HOOK_CONTINUE, HOOK_SKIP_ORIGINAL };
namespace mods {
template<class T> T arg(void* args, int n) { return std::any_cast<T>(static_cast<std::any*>(args)[n]); }
template<class T> T& arg_ref(void* args, int n) { return *std::any_cast<T>(&static_cast<std::any*>(args)[n]); }
}
constexpr int kBossRushStateHub=0, kBossRushStateCaveOfOrdeals=3;
const char* kBossRushReturnStage="D_MN09C";
const char* kBossRushDarknutAreaStage="D_DLBR0";
const char* kCaveOfOrdealsStage="D_SB01";
const char* kIntroSkipStage="F_SP108";
constexpr s16 kBossRushReturnPoint=0, kCaveOfOrdealsPoint=0;
@ARENA_POINT@
constexpr s8 kBossRushReturnRoom=0, kBossRushReturnLayer=0;
constexpr s8 kBossRushDarknutAreaRoom=51, kBossRushDarknutAreaLayer=0;
constexpr s8 kCaveOfOrdealsRoom=0, kCaveOfOrdealsLayer=-1, kIntroSkipRoom=0;
bool active=true, resetting=false;
bool survivors=false;
bool survivors_arena_active(){return survivors;}
bool sHubArrivalWarpPending=false, sBossRushArrivalReady=true;
int state=3, bossIndex=0, stay=0;
unsigned restartParam=0;
void cancel_clear_timer() {}
void reset_cave_boss_visits() {}
void dComIfGs_setRestartRoomParam(unsigned value) { restartParam=value; }
std::string current="D_SB01";
bool is_bossrush_game_mode_active() { return active; }
bool ensure_bossrush_runtime_for_save() { return active; }
bool is_boss_rush() { return active; }
int boss_rush_state() { return state; }
void set_boss_rush_state(int value) { state=value; }
void set_boss_rush_index(int value) { bossIndex=value; }
bool is_current_stage_name(const char* value) { return current==value; }
bool is_bossrush_darknut_area_stage() { return current==kBossRushDarknutAreaStage && stay==51; }
int dComIfGp_roomControl_getStayNo() { return stay; }
dSv_save_c* dComIfGs_getSaveData() { return nullptr; }
bool is_opening_stage(const char* stage,s16,s8,s8) { return stage && std::strcmp(stage,"TITLE")==0; }
bool is_reset_to_opening_transition() { return resetting; }
bool is_vanilla_new_file_stage(const char*,s16,s8,s8) { return false; }
bool is_intro_skipped() { return false; }
void prepare_bossrush_start() {}
void prepare_intro_skip_start() {}
void set_bossrush_return_place() {}
void clear_pending_midna_flow_action() {}
void clear_hub_confirm_state() {}
void reset_hub_actor_ids() {}
void reset_direct_final_boss_state() {}
void reset_bossrush_hazards() {}
constexpr int kBossRushStateReplay=2, kBossRushEntryCount=18;
bool ready=true, next=false, sBossRushWarpInFlight=false, sBossRushWarpPending=false;
bool sCaveArrivalWarpPending=false, sBossRushArrivalAnimating=false;
bool can_update_bossrush_gameplay(){return ready;}
bool dComIfGp_isEnableNextStage(){return next;}
int bossWarps=0;
void set_bossrush_next_stage(){++bossWarps;}
void dComIfGp_event_reset(){}
struct cXyz {float x,y,z; bool operator==(const cXyz&) const = default;};
cXyz restartPosition{};
short restartYaw=0; signed char restartRoom=-1;
void dComIfGs_setRestartRoom(const cXyz& p,short yaw,signed char room){restartPosition=p;restartYaw=yaw;restartRoom=room;}
std::any nextArgs[6];
HookAction on_set_next_stage_pre(ModContext*,void*,void*,void*);
void dComIfGp_setNextStage(const char* stage,s16 point,s8 room,s8 layer){
    nextArgs[0]=stage;nextArgs[1]=point;nextArgs[2]=room;nextArgs[3]=layer;
    on_set_next_stage_pre(nullptr,nextArgs,nullptr,nullptr);
}
'''

# Read the real destination point so the test catches accidental restart spawns.
stubs = stubs.replace("@ARENA_POINT@", re.search(
    r"constexpr s16 kBossRushDarknutAreaPoint = [^;]+;", source).group())

spawner = (Path(__file__).resolve().parents[1] / "src/enemy_spawner.cpp").read_text()
# Compile the real process callbacks too: the room check runs before actor_type
# has been initialized, and nested native processes must retain cleared flags.
functions = "\n".join(function(name, spawner) for name in (
    "is_test_actor", "after_create_child", "before_process", "after_process", "enemy_spawner_process_active",
)) + "\n"
assert "add_post<SpawnerProcessHook>(svc_hook, after_process)" in spawner
functions += "\n".join(function(name) for name in (
    "is_bossrush_darknut_area_active", "on_bossrush_area_dungeon_bit_pre",
    "on_bossrush_area_switch_pre", "on_bossrush_area_actor_name_post",
    "prepare_darknut_area_entry", "prepare_cave_entrance_return",
    "prepare_hub_return_from_cave", "set_next_stage_args", "on_cave_gameover_close_pre", "on_set_next_stage_pre",
    "cave_boss_warp_available", "warp_to_cave_boss", "warp_back_to_cave",
))

cases = r'''
void reset(const char* stage="D_SB01", int room=0, int mode=3) {
    current=stage; stay=room; state=mode; active=true; resetting=false;
    sHubArrivalWarpPending=false; sBossRushArrivalReady=true;
    gameOverStatus=0; gameOverType=0;
}
void route(const char* requested, const char* expected, int expectedState, int expectedRoom,
           int expectedPoint, int expectedLayer) {
    std::any args[]={requested,s16(42),s8(12),s8(2),float(7.5),unsigned(9)};
    assert(on_set_next_stage_pre(nullptr,args,nullptr,nullptr)==HOOK_CONTINUE);
    assert(std::strcmp(mods::arg<const char*>(args,0),expected)==0);
    assert(state==expectedState);
    assert(mods::arg<s8>(args,2)==expectedRoom);
    assert(mods::arg<s16>(args,1)==expectedPoint);
    assert(mods::arg<s8>(args,3)==expectedLayer);
    assert(mods::arg<float>(args,4)==7.5 && mods::arg<unsigned>(args,5)==9);
}
int main() {
    // Fairy detours switch to replay state before the normal Cave-exit hook.
    reset("D_SB01",19);
    assert(!warp_to_cave_boss(18) && bossWarps==0);
    for(bool* busy:{&sBossRushWarpInFlight,&sBossRushWarpPending,&next,&sCaveArrivalWarpPending,&sBossRushArrivalAnimating}){
        *busy=true;assert(!warp_to_cave_boss(5));*busy=false;
    }
    ready=false;assert(!warp_to_cave_boss(5));ready=true;
    assert(warp_to_cave_boss(5) && state==2 && bossIndex==5 && bossWarps==1);
    route("D_MN06B","D_MN06B",2,12,42,2);
    current="D_MN06B";
    const cXyz saved{12,34,56};
    warp_back_to_cave(saved,-123,s8(19));
    assert(state==3 && bossIndex==0 && restartPosition==saved && restartYaw==-123 && restartRoom==19);
    assert(restartParam==0 && sCaveArrivalWarpPending && sBossRushWarpInFlight && !sBossRushArrivalReady);
    assert(std::strcmp(mods::arg<const char*>(nextArgs,0),"D_SB01")==0);
    assert(mods::arg<s16>(nextArgs,1)==-1 && mods::arg<s8>(nextArgs,2)==19 && mods::arg<s8>(nextArgs,3)==-1);
    sCaveArrivalWarpPending=sBossRushWarpInFlight=false;
    // Entrance exit goes to the private, empty Darknut room in hub state.
    reset(); route("F_SP124","D_DLBR0",0,51,0,0);
    assert(!sHubArrivalWarpPending);
    // dStage_playerInit uses restart coordinates and unmodified room bits for
    // point -1. Other points use authored coordinates but can still inherit a
    // warp/demo parameter override. Exercise the destination after that boundary.
    for (unsigned stale : {0u, 0xCA000u, 0xCA009u}) {
        reset(); restartParam=stale;
        route("F_SP124","D_DLBR0",0,51,0,0);
        assert(restartParam==0);
        const unsigned authoredParam=0x10000u;
        unsigned playerParam=kBossRushDarknutAreaPoint==-1 ? restartParam :
            ((restartParam!=0 ? restartParam : authoredParam) & ~0x3fu) | kBossRushDarknutAreaRoom;
        assert(playerParam==(authoredParam | 51u));
        current=kBossRushDarknutAreaStage; stay=playerParam & 0x3f;
        assert(is_bossrush_darknut_area_active());
        dStage_objectNameInf info{fpcNm_B_TN_e}; auto* actor=&info;
        on_bossrush_area_actor_name_post(nullptr,nullptr,&actor,nullptr);
        assert(actor==nullptr);
    }
    // The new mode reuses room admission without requiring Boss Rush state.
    active=false;survivors=true;
    assert(is_bossrush_darknut_area_active());
    current="F_SP121";stay=6;assert(!is_bossrush_darknut_area_active());
    current="F_SP124";stay=0;assert(!is_bossrush_darknut_area_active());
    current="D_MN08";stay=0;assert(!is_bossrush_darknut_area_active());
    current="D_MN09A";stay=50;assert(!is_bossrush_darknut_area_active());
    survivors=false;assert(!is_bossrush_darknut_area_active());
    active=true;
    // Fairy exits on every tenth floor, including alternate fountain choices.
    for (int floor : {9,19,29,39,49}) {
        for (const char* spring : {"F_SP108","F_SP115","F_SP116","F_SP113"}) {
            reset("D_SB01",floor);
            route(spring,"D_MN09C",0,0,0,0);
            assert(sHubArrivalWarpPending && !sBossRushArrivalReady);
        }
        // Descending/continuing inside the Cave must retain the exact spawn.
        reset("D_SB01",floor); route("D_SB01","D_SB01",3,12,42,2);
    }
    // Both confirmed answers resume through native death recovery, then
    // always target the Cave entrance, regardless of the original exit/floor.
    for (int floor : {0,9,19,29,39,49}) {
        for (const char* nativeTarget : {"F_SP124","D_SB01","D_MN09C"}) {
            for (int answer : {0,1}) {
                reset("D_SB01",floor);
                dMenu_save_c menu{answer}; dGameover_c gameover{true,&menu};
                std::any args[]={&gameover};
                on_cave_gameover_close_pre(nullptr,args,nullptr,nullptr);
                assert(menu.mEndStatus==1);
                on_cave_gameover_close_pre(nullptr,args,nullptr,nullptr);
                assert(menu.mEndStatus==1);
                gameOverStatus=2; // native saveClose_proc resumes PROC_DEAD
                restartParam=0xC9009;
                route(nativeTarget,"D_SB01",3,0,0,-1);
                assert(restartParam==0 && !sHubArrivalWarpPending);
                // After scene initialization, the normal exit still goes to the arena.
                gameOverStatus=0; stay=0;
                route("F_SP124","D_DLBR0",0,51,0,0);
            }
        }
    }
    // Other saves, other stages and demo/save prompts keep native behavior.
    for (int scenario=0;scenario<5;++scenario) {
        reset();
        if (scenario==0) active=false;
        if (scenario==1) current="D_MN06B";
        if (scenario==2) gameOverType=1;
        if (scenario==3) resetting=true;
        if (scenario==4) gameOverType=2;
        dMenu_save_c menu{0}; dGameover_c gameover{true,&menu};
        std::any args[]={&gameover};
        on_cave_gameover_close_pre(nullptr,args,nullptr,nullptr);
        assert(menu.mEndStatus==0);
    }
    reset();
    dMenu_save_c pendingMenu{2}; dGameover_c pendingGameover{false,&pendingMenu};
    std::any pendingArgs[]={&pendingGameover};
    on_cave_gameover_close_pre(nullptr,pendingArgs,nullptr,nullptr);
    assert(pendingMenu.mEndStatus==2);
    // Both arena doors lead to the Cave entrance, including Temple destination.
    reset("D_DLBR0",51,0); route("D_MN06","D_SB01",3,0,0,-1);
    reset("D_DLBR0",51,0); route("D_MN06B","D_SB01",3,0,0,-1);
    // Explicit hub returns must not be captured by the entrance route.
    reset(); route("D_MN09C","D_MN09C",0,0,0,0);
    reset("D_DLBR0",51,0); route("D_MN09C","D_MN09C",0,12,42,2);
    // Vanilla saves, actual Darknut fights and title/reset paths pass through.
    reset(); active=false; route("F_SP124","F_SP124",3,12,42,2);
    reset("D_MN06B",51,2); route("D_MN06","D_MN06",2,12,42,2);
    reset(); route("TITLE","TITLE",3,12,42,2);
    reset(); resetting=true; route("F_SP124","F_SP124",3,12,42,2);
    // Completion/gate overrides must be in effect before actor creation and
    // must leave the real arena and non-Boss-Rush saves alone.
    reset("D_DLBR0",51,0);
    for (int bit : {3,5,7}) {
        std::any args[]={nullptr,bit}; int result=0;
        assert(on_bossrush_area_dungeon_bit_pre(nullptr,args,&result,nullptr)==HOOK_SKIP_ORIGINAL);
        assert(result==1);
    }
    for (int room : {51}) {
        std::any args[]={nullptr,2,room}; int result=0;
        assert(on_bossrush_area_switch_pre(nullptr,args,&result,nullptr)==HOOK_SKIP_ORIGINAL);
        assert(result==1);
    }
    for (int room : {-1,0,50,52}) {
        std::any args[]={nullptr,2,room}; int result=-1;
        assert(on_bossrush_area_switch_pre(nullptr,args,&result,nullptr)==HOOK_CONTINUE);
        assert(result==-1);
    }
    for (int bit : {-1,255,256}) {
        std::any args[]={nullptr,bit,51}; int result=-1;
        assert(on_bossrush_area_switch_pre(nullptr,args,&result,nullptr)==HOOK_CONTINUE);
        assert(result==-1);
    }
    // Simulate the exact first-create boundary: the process is registered but
    // does not have actor_type yet. Its queries must use the native save state.
    process_class testEnemy{42}, nativeGate{43};
    s_testActors.insert(42);
    std::any processArgs[]={process_method_func(nullptr),static_cast<void*>(&testEnemy)};
    std::any switchArgs[]={nullptr,2,51}; int switchResult=-1;
    std::any bossArgs[]={nullptr,3}; int bossResult=-1;
    auto checkRoom = [&](int cleared) {
        for (int native : {0,1}) {
            switchResult=native; bossResult=native;
            const auto action=cleared ? HOOK_SKIP_ORIGINAL : HOOK_CONTINUE;
            assert(on_bossrush_area_switch_pre(nullptr,switchArgs,&switchResult,nullptr)==action);
            assert(on_bossrush_area_dungeon_bit_pre(nullptr,bossArgs,&bossResult,nullptr)==action);
            assert(switchResult==(cleared ? 1 : native) && bossResult==switchResult);
        }
    };
    assert(!enemy_spawner_process_active());
    before_process(nullptr,processArgs,nullptr,nullptr);
    assert(enemy_spawner_process_active());
    checkRoom(0); // fopAc_Create uses native admission, not the forced cleared state.
    // Non-process callbacks cannot inherit ownership even if their bytes look
    // like an owned process ID, and must still mask/restore the outer context.
    process_class request{42,true,false};
    std::any requestArgs[]={process_method_func(nullptr),static_cast<void*>(&request)};
    before_process(nullptr,requestArgs,nullptr,nullptr);
    assert(!enemy_spawner_process_active());checkRoom(1);
    after_process(nullptr,requestArgs,nullptr,nullptr);
    assert(enemy_spawner_process_active());checkRoom(0);
    std::any skippedArgs[]={process_method_func(nullptr),static_cast<void*>(&nativeGate)};
    after_process(nullptr,skippedArgs,nullptr,nullptr); // another mod skipped its pre
    checkRoom(0);
    before_process(nullptr,processArgs,nullptr,nullptr); // nested profile creation
    checkRoom(0);
    processArgs[1]=static_cast<void*>(&nativeGate);
    before_process(nullptr,processArgs,nullptr,nullptr);
    checkRoom(1); // a nested gate still sees the open/cleared room
    after_process(nullptr,processArgs,nullptr,nullptr);
    checkRoom(0);
    processArgs[1]=static_cast<void*>(nullptr);
    before_process(nullptr,processArgs,nullptr,nullptr);
    checkRoom(1);
    after_process(nullptr,processArgs,nullptr,nullptr);
    after_process(nullptr,processArgs,nullptr,nullptr);
    checkRoom(0);
    after_process(nullptr,processArgs,nullptr,nullptr);
    checkRoom(1);
    assert(!enemy_spawner_process_active() && s_testProcessStack.empty());
    // The spawner exemption follows asynchronously created eggs/other children.
    // Registration happens before the base actor is initialized or admitted.
    fpc_ProcID childId=44;
    std::any childArgs[]={s16(0),fpc_ProcID(42)};
    after_create_child(nullptr,childArgs,&childId,nullptr);
    assert(s_testActors.contains(childId));
    process_class egg{childId};
    std::any eggArgs[]={process_method_func(nullptr),static_cast<void*>(&egg)};
    before_process(nullptr,eggArgs,nullptr,nullptr);
    assert(enemy_spawner_process_active()); checkRoom(0);
    after_process(nullptr,eggArgs,nullptr,nullptr); checkRoom(1);
    childArgs[1]=childId; fpc_ProcID grandchildId=45;
    after_create_child(nullptr,childArgs,&grandchildId,nullptr);
    assert(s_testActors.contains(grandchildId));
    childArgs[1]=fpc_ProcID(43); fpc_ProcID nativeChildId=46;
    after_create_child(nullptr,childArgs,&nativeChildId,nullptr);
    assert(!s_testActors.contains(nativeChildId));
    childArgs[1]=fpc_ProcID(42); fpc_ProcID failure=fpcM_ERROR_PROCESS_ID_e;
    after_create_child(nullptr,childArgs,&failure,nullptr);
    assert(!s_testActors.contains(failure));
    after_create_child(nullptr,nullptr,&failure,nullptr);
    after_create_child(nullptr,childArgs,nullptr,nullptr);
    // Scope still works for an initialized actor during execution/deletion.
    process_method_class methods{nullptr, +[](void*){return 1;}, +[](void*){return 1;}};
    fopAc_ac_c initializedEnemy; initializedEnemy.id=42;
    initializedEnemy.initialized=true; initializedEnemy.sub_method=&methods;
    processArgs[0]=methods.execute_method; processArgs[1]=static_cast<void*>(&initializedEnemy);
    before_process(nullptr,processArgs,nullptr,nullptr); checkRoom(0);
    after_process(nullptr,processArgs,nullptr,nullptr); checkRoom(1);
    processArgs[0]=methods.delete_method;
    before_process(nullptr,processArgs,nullptr,nullptr);
    assert(!s_testActors.contains(42));
    after_process(nullptr,processArgs,nullptr,nullptr);
    assert(!enemy_spawner_process_active());
    // Removing the parent does not retire a live child; each ID is cleaned up
    // by its own delete callback, including descendants.
    assert(s_testActors.contains(childId) && s_testActors.contains(grandchildId));
    initializedEnemy.id=childId;
    before_process(nullptr,processArgs,nullptr,nullptr);
    after_process(nullptr,processArgs,nullptr,nullptr);
    assert(!s_testActors.contains(childId) && s_testActors.contains(grandchildId));
    for (int profile=0;profile<=testDoorProfile;++profile) {
        dStage_objectNameInf info{profile}; auto* result=&info;
        on_bossrush_area_actor_name_post(nullptr,nullptr,&result,nullptr);
        assert((result!=nullptr)==(profile==testDoorProfile));
    }
    for (const char* stage : {"D_MN06B","D_SB01","D_MN09C"}) {
        reset(stage,51,0);
        std::any args[]={nullptr,3,51}; int result=0;
        assert(on_bossrush_area_dungeon_bit_pre(nullptr,args,&result,nullptr)==HOOK_CONTINUE);
        assert(on_bossrush_area_switch_pre(nullptr,args,&result,nullptr)==HOOK_CONTINUE);
        dStage_objectNameInf info{fpcNm_B_TN_e}; auto* actor=&info;
        on_bossrush_area_actor_name_post(nullptr,nullptr,&actor,nullptr);
        assert(actor==&info);
    }
    reset("D_DLBR0",51,0); active=false;
    std::any args[]={nullptr,3,51}; int result=0;
    assert(on_bossrush_area_dungeon_bit_pre(nullptr,args,&result,nullptr)==HOOK_CONTINUE);
    assert(on_bossrush_area_switch_pre(nullptr,args,&result,nullptr)==HOOK_CONTINUE);
    std::cout << "Boss Rush Cave/arena route and isolation checks passed\n";
}
'''

with tempfile.TemporaryDirectory() as temporary:
    folder = Path(temporary)
    cpp = folder / "routes.cpp"
    binary = folder / "routes"
    cpp.write_text(stubs + functions + cases)
    subprocess.run(["g++", "-std=c++20", "-Wall", "-Wextra", "-I", str(Path(__file__).resolve().parents[1] / "src"), str(cpp), "-o", str(binary)], check=True)
    subprocess.run([str(binary)], check=True)
